#!/usr/bin/env node
// Riftcast: tournament stream overlay for Riftbound.
//   Control panel:  http://localhost:7420/control   (browser, or an OBS Custom Browser Dock)
//   OBS overlay:    http://localhost:7420/overlay   (Browser Source, 1920x1080)
//   Buttons:        http://localhost:7420/api/do?type=points&player=0&delta=1   (Stream Deck "Website" action)

import http from 'node:http'
import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { fetchAllCards, fetchGalleryCards, mergeCardSources, CardIndex, parseDecklist } from './lib/cards.js'
import { initialState, reduce } from './lib/state.js'
import { CameraEngine } from './lib/vision/engine.js'
import { RiftAtlasLink, RIFTATLAS_ORIGINS } from './lib/riftatlas.js'
import { newCode, PhoneLinks } from './lib/phones.js'
import { PairingsLink } from './lib/pairings.js'
import { Updater, RESTART_CODE } from './lib/update.js'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const PUBLIC = path.join(ROOT, 'public')
const POINTS = path.join(ROOT, 'points')
const DATA = process.env.RIFTCAST_DATA ?? path.join(ROOT, 'data')
const IMG_DIR = path.join(DATA, 'img')
// v2: riftcodex plus the official gallery's newer sets (a new name so older saved lists are fetched again)
const CARDS_FILE = path.join(DATA, 'cards-v2.json')
const STATE_FILE = path.join(DATA, 'state.json')
const PORT = Number(process.env.PORT ?? 7420)
// Local only by default; HOST=0.0.0.0 lets a laptop or tablet on the same network open the control panel.
// (Players' phones don't need this: their points app links through the online relay.)
const HOST = process.env.HOST ?? '127.0.0.1'
const CARDS_MAX_AGE_MS = 24 * 3600_000
const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version

fs.mkdirSync(IMG_DIR, { recursive: true })

let index = null
let cardsStatus = { loading: false, count: 0, updatedAt: null, error: null }
let state = loadState()
const clients = new Set()

function loadState() {
  const fresh = initialState()
  try {
    const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'))
    // Saved state wins, but new settings added since keep their defaults.
    return { ...fresh, ...saved, settings: { ...fresh.settings, ...saved.settings } }
  } catch {
    return fresh
  }
}

let saveTimer = null
function saveState() {
  clearTimeout(saveTimer)
  saveTimer = setTimeout(() => {
    fsp.writeFile(STATE_FILE + '.tmp', JSON.stringify(state, null, 2)).then(() => fsp.rename(STATE_FILE + '.tmp', STATE_FILE)).catch((e) => console.error('Saving state failed:', e.message))
  }, 300)
}

/** Save right away (before a restart). */
function saveStateNow() {
  clearTimeout(saveTimer)
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2))
  } catch (e) {
    console.error('Saving state failed:', e.message)
  }
}

const snapshot = () => JSON.stringify({ state, cardsStatus, camera: camera.publicStatus(), riftatlas: riftatlas.publicStatus(), phones: phoneLinks.status(), pairings: pairingsLink.publicStatus(), update: updater.status(), serverNow: Date.now() })

function broadcast() {
  clearTimeout(cameraBroadcastTimer)
  cameraBroadcastTimer = null
  const msg = `data: ${snapshot()}\n\n`
  for (const res of clients) res.write(msg)
  phoneLinks.publish()
}

function ensurePhoneCodes(force = false) {
  if (force || !state.phoneCodes?.[0] || !state.phoneCodes?.[1] || !state.tableCode) apply({ type: 'phoneCodes', codes: [newCode(), newCode()], table: newCode() })
  phoneLinks.sync()
}

// Camera updates come several times a second; pages get at most four a second.
let cameraBroadcastTimer = null
function broadcastSoon() {
  if (!cameraBroadcastTimer) cameraBroadcastTimer = setTimeout(broadcast, 250)
}

const riftatlas = new RiftAtlasLink({ getIndex: () => index, getState: () => state, apply })
const phoneLinks = new PhoneLinks({ getState: () => state, apply, onChange: () => broadcastSoon() })
const pairingsLink = new PairingsLink({ getState: () => state, apply, getIndex: () => index, onChange: () => broadcastSoon() })
const updater = new Updater({ root: ROOT, version: VERSION, onChange: () => broadcastSoon() })

const camera = new CameraEngine({
  dataDir: DATA,
  getIndex: () => index,
  getState: () => state,
  show: (cardId, owner) => apply({ type: 'show', cardId, ...(owner !== null && owner !== undefined ? { player: owner } : {}), source: 'camera' }),
  onChange: broadcastSoon,
})

function apply(action) {
  state = reduce(state, action, { index, parseDecklist, now: Date.now() })
  saveState()
  phoneLinks.sync() // follow code changes (swap sides moves each player's link with them)
  broadcast()
  if (action.type === 'loadDeck') prefetchDeckImages()
  // A new game starts on a fresh table: whatever the camera sees now is not "played".
  if (action.type === 'newGame' || action.type === 'newMatch') camera.resetTable()
  // New players, new phone codes: the last match's phones stop working.
  if (action.type === 'newMatch') ensurePhoneCodes(true)
  return state
}

// ---- Card data ----

async function loadCards({ force = false } = {}) {
  let cached = null
  try {
    const stat = await fsp.stat(CARDS_FILE)
    cached = { cards: JSON.parse(await fsp.readFile(CARDS_FILE, 'utf8')), mtime: stat.mtimeMs }
  } catch {}
  if (cached) setCards(cached.cards, cached.mtime)
  if (!force && cached && Date.now() - cached.mtime < CARDS_MAX_AGE_MS) return

  cardsStatus = { ...cardsStatus, loading: true, error: null }
  broadcast()
  try {
    const main = await fetchAllCards()
    // New sets reach the official gallery first: fill in what riftcodex hasn't added yet.
    let extra = []
    try {
      extra = mergeCardSources(main, await fetchGalleryCards()).slice(main.length)
    } catch (e) {
      console.error(`Official card gallery: ${e.message} (riftcodex cards only)`)
    }
    const cards = [...main, ...extra]
    await fsp.writeFile(CARDS_FILE, JSON.stringify(cards))
    setCards(cards, Date.now())
    const sets = [...new Set(extra.map((c) => c.set))]
    console.log(`Loaded ${cards.length} Riftbound cards from riftcodex${extra.length ? ` (+${extra.length} from the official gallery: ${sets.join(', ')})` : ''}`)
  } catch (e) {
    cardsStatus = { ...cardsStatus, error: `Card update failed: ${e.message}${cached ? ' (using saved cards)' : ''}` }
    console.error(cardsStatus.error)
  } finally {
    cardsStatus = { ...cardsStatus, loading: false }
    broadcast()
  }
}

function setCards(cards, mtime) {
  index = new CardIndex(cards)
  cardsStatus = { ...cardsStatus, count: cards.length, updatedAt: mtime }
}

// ---- Card images: served from a local cache so the stream never waits on the CDN ----

const inflight = new Map()
function imagePath(id) {
  return path.join(IMG_DIR, `${id.replace(/[^a-zA-Z0-9_-]/g, '')}.img`)
}

async function ensureImage(id) {
  const file = imagePath(id)
  if (fs.existsSync(file)) return file
  if (inflight.has(id)) return inflight.get(id)
  const card = index?.byId.get(id)
  if (!card?.imageUrl) throw new Error('No image for card')
  const job = (async () => {
    const res = await fetch(card.imageUrl)
    if (!res.ok) throw new Error(`Image download answered ${res.status}`)
    const buf = Buffer.from(await res.arrayBuffer())
    await fsp.writeFile(file + '.tmp', buf)
    await fsp.rename(file + '.tmp', file)
    return file
  })().finally(() => inflight.delete(id))
  inflight.set(id, job)
  return job
}

async function prefetchDeckImages() {
  const ids = new Set()
  for (const pl of state.players) {
    for (const id of [pl.legendId, ...pl.battlefieldIds, ...pl.main.map((e) => e.cardId), ...pl.sideboard.map((e) => e.cardId)]) if (id) ids.add(id)
  }
  for (const id of ids) await ensureImage(id).catch(() => {})
}

function sniffType(buf) {
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png'
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg'
  if (buf.slice(8, 12).toString() === 'WEBP') return 'image/webp'
  return 'application/octet-stream'
}

// ---- HTTP ----

const MIME = { '.webmanifest': 'application/manifest+json', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' }

function sendJson(res, code, body) {
  res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store' })
  res.end(JSON.stringify(body))
}

async function readBody(req) {
  let body = ''
  for await (const chunk of req) {
    body += chunk
    if (body.length > 1_000_000) throw new Error('Request too large')
  }
  return body ? JSON.parse(body) : {}
}

/** Query-string actions for buttons: numbers and booleans come in as text. */
function actionFromQuery(params) {
  const action = {}
  for (const [k, v] of params) {
    if (v === 'true' || v === 'false') action[k] = v === 'true'
    else if (v !== '' && !Number.isNaN(Number(v)) && k !== 'cardId' && k !== 'name' && k !== 'record') action[k] = Number(v)
    else action[k] = v
  }
  return action
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost')
  // The Rift Atlas connector runs on play.riftatlas.com and reports to this local server.
  // Only that site may (browsers also ask the user before a website reaches a local server).
  const origin = req.headers.origin
  if (origin && RIFTATLAS_ORIGINS.includes(origin) && url.pathname.startsWith('/api/riftatlas')) {
    res.setHeader('access-control-allow-origin', origin)
    res.setHeader('vary', 'origin')
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'access-control-allow-methods': 'POST, GET', 'access-control-allow-headers': 'content-type', 'access-control-allow-private-network': 'true', 'access-control-max-age': '600' })
      return res.end()
    }
  }
  try {
    if (url.pathname === '/' ) {
      res.writeHead(302, { location: '/control' })
      return res.end()
    }
    if (url.pathname === '/api/events') {
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' })
      res.write(`data: ${snapshot()}\n\n`)
      clients.add(res)
      const ping = setInterval(() => res.write(': ping\n\n'), 20_000)
      req.on('close', () => {
        clearInterval(ping)
        clients.delete(res)
      })
      return
    }
    if (url.pathname === '/api/update') return sendJson(res, 200, updater.status())
    if (url.pathname === '/api/update/check' && req.method === 'POST') return sendJson(res, 200, await updater.check())
    if (url.pathname === '/api/update/install' && req.method === 'POST') {
      try {
        const files = await updater.install()
        console.log(`Updated to Riftcast ${updater.latest.version} (${files} files).`)
        const st = updater.status()
        if (st.autoRestart) {
          console.log('Restarting…')
          // Let the control panel hear the answer, save the state, then hand over to the launcher.
          setTimeout(() => {
            saveStateNow()
            process.exit(RESTART_CODE)
          }, 800)
        } else console.log('Close this window and start Riftcast again to finish the update.')
        return sendJson(res, 200, { ok: true, files, ...st })
      } catch (e) {
        return sendJson(res, 200, { ok: false, error: updater.error ?? e.message, ...updater.status() })
      }
    }
    if (url.pathname === '/api/state') return sendJson(res, 200, { state, cardsStatus, serverNow: Date.now() })
    if (url.pathname === '/api/cards') return sendJson(res, 200, index ? index.cards : [])
    if (url.pathname === '/api/action' && req.method === 'POST') {
      const action = await readBody(req)
      return sendJson(res, 200, { ok: true, state: apply(action) })
    }
    if (url.pathname === '/api/do') {
      apply(actionFromQuery(url.searchParams))
      return sendJson(res, 200, { ok: true })
    }
    if (url.pathname === '/api/search') {
      return sendJson(res, 200, index ? index.search(url.searchParams.get('q') ?? '', 20) : [])
    }
    if (url.pathname === '/api/showByName') {
      // For buttons/scripts: /api/showByName?name=Trifarian%20Captain&player=1
      const card = index?.resolve(url.searchParams.get('name') ?? '') ?? index?.search(url.searchParams.get('name') ?? '', 1)[0]
      if (!card) return sendJson(res, 404, { ok: false, error: 'No card by that name' })
      const player = url.searchParams.get('player')
      apply({ type: 'show', cardId: card.id, ...(player !== null ? { player: Number(player) } : {}) })
      return sendJson(res, 200, { ok: true, card })
    }
    if (url.pathname.startsWith('/api/camera')) return await cameraRoute(url, req, res)
    if (url.pathname === '/api/phones') return sendJson(res, 200, { ok: true, codes: state.phoneCodes, tableCode: state.tableCode, ...phoneLinks.status() })
    if (url.pathname === '/api/phones/new' && req.method === 'POST') {
      ensurePhoneCodes(true)
      return sendJson(res, 200, { ok: true, codes: state.phoneCodes, tableCode: state.tableCode })
    }
    if (url.pathname.startsWith('/api/pairings/') && req.method === 'POST') {
      const body = await readBody(req)
      const what = url.pathname.slice('/api/pairings/'.length)
      try {
        if (what === 'link') await pairingsLink.link(body.ref)
        else if (what === 'unlink') pairingsLink.unlink()
        else if (what === 'refresh') await pairingsLink.refresh()
        else if (what === 'feature') pairingsLink.feature(String(body.matchId ?? ''))
        else return sendJson(res, 404, { ok: false, error: 'Unknown Pairings request' })
      } catch (e) {
        return sendJson(res, 400, { ok: false, error: e.message })
      }
      return sendJson(res, 200, { ok: true, pairings: pairingsLink.publicStatus() })
    }
    if (url.pathname === '/api/riftatlas/event' && req.method === 'POST') {
      const result = riftatlas.handle(await readBody(req))
      broadcastSoon()
      return sendJson(res, 200, result)
    }
    if (url.pathname === '/api/riftatlas/status') return sendJson(res, 200, riftatlas.publicStatus())
    if (url.pathname === '/api/refreshCards' && req.method === 'POST') {
      loadCards({ force: true })
      return sendJson(res, 200, { ok: true })
    }
    if (url.pathname.startsWith('/img/')) {
      const id = decodeURIComponent(url.pathname.slice(5))
      const file = await ensureImage(id)
      const buf = await fsp.readFile(file)
      res.writeHead(200, { 'content-type': sniffType(buf), 'cache-control': 'public, max-age=31536000, immutable' })
      return res.end(buf)
    }

    // Static pages: /control, /overlay and their files.
    // /points/ is a local preview of the players' points app (the real one lives on GitHub Pages).
    if (url.pathname === '/points') return res.writeHead(302, { location: '/points/' }).end()
    const pages = { '/control': '/control.html', '/overlay': '/overlay.html', '/break': '/break.html', '/camera': '/camera.html', '/points/': '/points/index.html' }
    let rel = pages[url.pathname] ?? url.pathname
    let base = PUBLIC
    if (rel.startsWith('/points/') && rel !== '/points/relay.js') {
      base = POINTS
      rel = rel.slice('/points'.length)
    } else if (rel === '/points/relay.js') rel = '/relay.js'
    const file = path.normalize(path.join(base, rel))
    if (!file.startsWith(base + path.sep)) return sendJson(res, 403, { error: 'Forbidden' })
    const buf = await fsp.readFile(file).catch(() => null)
    if (!buf) return sendJson(res, 404, { error: 'Not found' })
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] ?? 'application/octet-stream', 'cache-control': 'no-cache' })
    res.end(buf)
  } catch (e) {
    sendJson(res, 400, { ok: false, error: e.message })
  }
})

async function readRaw(req, limit = 40_000_000) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > limit) throw new Error('Image too large')
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

let photoClock = 0


async function cameraRoute(url, req, res) {
  const route = url.pathname.slice('/api/camera'.length) || '/'
  if (route === '/') return sendJson(res, 200, camera.publicStatus())
  if (route === '/config' && req.method === 'POST') {
    await camera.updateConfig(await readBody(req))
    return sendJson(res, 200, { ok: true, camera: camera.publicStatus() })
  }
  if (route === '/sources') return sendJson(res, 200, { ok: true, sources: await camera.listSources() })
  if (route === '/frame') {
    if (!camera.frame) return sendJson(res, 404, { ok: false, error: 'No camera picture yet' })
    res.writeHead(200, { 'content-type': 'image/png', 'cache-control': 'no-store' })
    return res.end(camera.frame)
  }
  if (route === '/reset') {
    camera.resetTable()
    return sendJson(res, 200, { ok: true })
  }
  if (route === '/auto') {
    // For buttons: /api/camera/auto?on=toggle|true|false
    const on = url.searchParams.get('on') ?? 'toggle'
    await camera.updateConfig({ auto: on === 'toggle' ? !camera.config.auto : on === 'true' })
    return sendJson(res, 200, { ok: true, auto: camera.config.auto })
  }
  if (route === '/enabled') {
    const on = url.searchParams.get('on') ?? 'toggle'
    await camera.updateConfig({ enabled: on === 'toggle' ? !camera.config.enabled : on === 'true' })
    return sendJson(res, 200, { ok: true, enabled: camera.config.enabled })
  }
  if (route === '/dismiss' && req.method === 'POST') {
    camera.dismissSuggestion((await readBody(req)).cardId)
    return sendJson(res, 200, { ok: true })
  }
  if (route === '/testPhoto' && req.method === 'POST') {
    // Try it with still photos: ?step=before (the table without the card), then ?step=after (with it).
    // The photo is replayed as if the camera had watched it for a few seconds.
    await camera.ensureIndex()
    const png = await readRaw(req)
    const step = url.searchParams.get('step')
    if (step === 'before') {
      camera.resetTable()
      photoClock = Date.now() / 1000
      camera.processPng(png, photoClock)
      camera.processPng(png, (photoClock += 1))
      return sendJson(res, 200, { ok: true, events: [] })
    }
    if (!photoClock) return sendJson(res, 400, { ok: false, error: 'Send the photo of the empty table first' })
    const events = []
    const until = photoClock + camera.config.tracker.stableSec + 1.5
    while (photoClock < until) events.push(...camera.processPng(png, (photoClock += 0.34)))
    const found = events.filter((e) => e.type !== 'ignored')
    return sendJson(res, 200, { ok: true, events: found.map(({ type, name, score, margin, owner }) => ({ type, name, score, margin, owner })) })
  }
  return sendJson(res, 404, { ok: false, error: 'Unknown camera request' })
}

server.listen(PORT, HOST, () => {
  console.log(`Riftcast ${VERSION} running.`)
  console.log(`  Control panel: http://localhost:${PORT}/control`)
  console.log(`  OBS overlay:   http://localhost:${PORT}/overlay  (Browser Source, 1920x1080)`)
  ensurePhoneCodes()
  pairingsLink.start()
  updater.start()
  loadCards().then(() => {
    prefetchDeckImages()
    if (camera.config.enabled) camera.start()
  })
})
