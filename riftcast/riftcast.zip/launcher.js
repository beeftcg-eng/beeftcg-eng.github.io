#!/usr/bin/env node
// Starts Riftcast and starts it again after a one-click update (server.js exits with code 75).
// start.bat / start.sh run this; `node server.js` on its own also works, without the auto-restart.
import { spawn } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const RESTART_CODE = 75

function run() {
  const child = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
    cwd: ROOT,
    stdio: 'inherit',
    env: { ...process.env, RIFTCAST_LAUNCHER: '1' },
  })
  // Ctrl+C reaches Riftcast too; just wait for it to finish.
  const ignore = () => {}
  process.on('SIGINT', ignore)
  process.on('SIGTERM', () => child.kill('SIGTERM'))
  child.on('exit', (code, signal) => {
    process.off('SIGINT', ignore)
    if (code === RESTART_CODE) {
      console.log('\nRestarting Riftcast with the update…\n')
      setTimeout(run, 500)
    } else process.exit(code ?? (signal ? 1 : 0))
  })
}
run()
