@echo off
rem Start Riftcast (Windows). Needs Node.js 22 or newer from https://nodejs.org
title Riftcast - keep this window open while streaming
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js isn't installed. Get the LTS version from https://nodejs.org,
  echo install it, then double-click start.bat again.
  start "" https://nodejs.org
  pause
  exit /b 1
)
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start "" http://localhost:7420/control"
node launcher.js
pause
