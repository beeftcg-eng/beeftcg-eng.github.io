#!/usr/bin/env node
// Accuracy check for the camera pipeline without a camera: real card images drawn onto a fake
// playmat with camera flaws, fed through the same tracker the live camera uses.
//   node scripts/vision-eval.js [trials=60] [seed=7]
// Needs data/cards-v2.json and data/fingerprints.* (start Riftcast and build the camera index once).
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { decodePng } from '../lib/png.js'
import { FingerprintDB, thumbUrl } from '../lib/vision/db.js'
import { Tracker, identify, sameName } from '../lib/vision/tracker.js'
import { makeMat, cloneImage, drawCard, cameraize, rng } from '../lib/vision/synth.js'
import { nameKey } from '../lib/cards.js'

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const DATA = path.join(ROOT, 'data')
const trials = Number(process.argv[2] ?? 60)
const seed = Number(process.argv[3] ?? 7)
const W = 1280, H = 720

const cards = JSON.parse(fs.readFileSync(path.join(DATA, 'cards-v2.json'), 'utf8'))
const byId = new Map(cards.map((c) => [c.id, c]))
const db = await FingerprintDB.load(DATA)
if (!db.size) throw new Error('No fingerprints yet: build the camera index first')
const cardInfo = (id) => {
  const c = byId.get(id)
  return c && { name: c.name, nameKey: nameKey(c.name) }
}

const rand = rng(seed)
const pool = cards.filter((c) => c.category !== 'Rune')
const evalDir = path.join(DATA, 'eval')
fs.mkdirSync(evalDir, { recursive: true })
async function cardImage(card) {
  // A different, larger render than the index uses, like a real card is.
  const file = path.join(evalDir, `${card.id}.png`)
  if (!fs.existsSync(file)) {
    const res = await fetch(thumbUrl(card.imageUrl).replace('w=160', 'w=420'))
    fs.writeFileSync(file, Buffer.from(await res.arrayBuffer()))
  }
  return decodePng(fs.readFileSync(file))
}

// Things that are not a face-up card: a sleeve back (Hidden cards are played face down) or a resting hand.
function fakeObject(kind, rand) {
  const w = 100, h = 140
  const data = new Uint8ClampedArray(w * h * 4)
  const base = kind === 'hand' ? [200, 150, 120] : [rand() * 200, rand() * 200, rand() * 200]
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const o = (y * w + x) * 4
    const logo = kind === 'facedown' && Math.hypot(x - 50, y - 70) < 25 ? 60 : 0
    const shade = kind === 'hand' ? Math.sin(x / 9) * 15 + y / 6 : 0
    data[o] = base[0] + logo + shade; data[o + 1] = base[1] + logo + shade; data[o + 2] = base[2] + logo + shade; data[o + 3] = 255
  }
  return { width: w, height: h, data }
}
const scores = { pos: [], neg: [] }

const mat = makeMat(W, H, seed)
const tally = { right: 0, wrongShown: 0, unsure: 0, unsureRightInList: 0, missed: 0 }
const wrong = []
let totalMs = 0
for (let t = 0; t < trials; t++) {
  const negative = t % 5 === 4 ? (t % 10 === 4 ? 'facedown' : 'hand') : null
  const card = pool[Math.floor(rand() * pool.length)]
  const img = negative ? fakeObject(negative, rand) : await cardImage(card)
  const width = [50, 65, 80][t % 3]
  const landscape = img.width > img.height
  const turn = rand() < 0.5 ? 0 : Math.PI // the far player's cards are upside down
  const angle = turn + (rand() - 0.5) * 0.3 + (landscape ? 0 : 0)
  const cx = 160 + rand() * (W - 320), cy = 130 + rand() * (H - 260)
  const castK = () => 0.85 + rand() * 0.3
  const look = { cast: [castK(), castK(), castK()], noise: 6, glare: rand() < 0.5 ? { x: cx + (rand() - 0.5) * width, y: cy + (rand() - 0.5) * width, r: width * 0.6, strength: 70 } : null }
  const sleeve = [rand() * 200, rand() * 200, rand() * 200]
  const shortSide = landscape ? (width * img.width) / img.height : width
  const tracker = new Tracker({ cardSize: { w: width / W, h: width / 0.716 / H } })
  let decision = null
  const recognize = (frame, pose) => identify(frame, pose, db, cardInfo)
  for (let f = 0; f < 14 && !decision; f++) {
    const frame = cloneImage(mat)
    if (f >= 4) drawCard(frame, img, { cx, cy, w: landscape ? shortSide : width, angle, sleeve })
    cameraize(frame, { seed: seed * 1000 + t * 20 + f, ...look })
    const started = Date.now()
    const events = tracker.process(frame, f / 3, recognize)
    totalMs += Date.now() - started
    decision = events.find((e) => e.type === 'show' || e.type === 'unsure') ?? null
  }
  const right = (id) => id && sameName(nameKey(byId.get(id).name), nameKey(card.name))
  if (negative) {
    tally.negatives = (tally.negatives ?? 0) + 1
    if (decision?.type === 'show') {
      tally.negativeShown = (tally.negativeShown ?? 0) + 1
      wrong.push(`${negative} shown as ${decision.name} ${decision.score.toFixed(2)}/${decision.margin.toFixed(2)}`)
    }
    if (decision?.score !== undefined) scores.neg.push([decision.score, decision.margin])
    continue
  }
  if (decision?.score !== undefined) scores.pos.push([decision.score, decision.margin, right(decision.cardId)])
  if (!decision) tally.missed++
  else if (decision.type === 'show') {
    if (right(decision.cardId)) tally.right++
    else {
      tally.wrongShown++
      wrong.push(`${card.name} (${width}px) shown as ${decision.name} ${decision.score.toFixed(2)}/${decision.margin.toFixed(2)}`)
    }
  } else {
    tally.unsure++
    if (right(decision.cardId) || decision.alternatives?.some((a) => right(a.id))) tally.unsureRightInList++
    wrong.push(`unsure: ${card.name} (${width}px) best ${decision.name} ${decision.score.toFixed(2)}/${decision.margin.toFixed(2)}`)
  }
}
console.log(`${trials} cards: ${tally.right} shown correctly, ${tally.wrongShown} shown WRONG, ${tally.unsure} left as suggestions (${tally.unsureRightInList} with the right card among them), ${tally.missed} missed`)
console.log(`not-a-card objects: ${tally.negatives ?? 0}, shown as a card: ${tally.negativeShown ?? 0}`)
if (process.env.SCORES) console.log(JSON.stringify(scores))
console.log(`average tracker time per frame: ${(totalMs / (trials * 14)).toFixed(1)} ms`)
for (const w of wrong) console.log('  ' + w)
