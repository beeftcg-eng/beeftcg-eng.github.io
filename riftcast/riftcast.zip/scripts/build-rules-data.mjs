#!/usr/bin/env node
// Rebuilds what the rules judge (supabase/functions/rules-judge) knows: Riot's Core Rules and
// Tournament Rules from the Rules Hub, and every card's rules text. Run it after a rules update or a
// new set, then redeploy the function (see supabase/functions/rules-judge/README.md).
// Also writes public/rules-data.json: the same rules split into numbered entries, plus card text,
// for the free offline rules search in the points app and the control panel.
// Needs pdftotext (poppler-utils).   Usage: node scripts/build-rules-data.mjs
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { nameKey } from '../lib/cards.js'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const OUT = path.join(HERE, '..', 'supabase', 'functions', 'rules-judge', 'data')
const SEARCH_OUT = path.join(HERE, '..', 'public', 'rules-data.json')
const HUB = 'https://playriftbound.com/en-us/rules-hub/'
const UA = { 'user-agent': 'Mozilla/5.0 (Riftcast rules data builder)' }

const tidy = (t) => t.replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim() + '\n'

/**
 * Numbered rules as [ref, text, heading] from pdftotext -layout, where each rule starts its line
 * ("729.1.a.   XP is a value…") and wrapped lines are indented. heading: the section the rule is in.
 */
function entries(layout) {
  const out = []
  let heading = ''
  for (const raw of layout.split('\n')) {
    const line = raw.replace(/\f/g, '').trimEnd()
    const m = /^\s{0,4}(\d{3}(?:\.(?:\d+|[a-z]))*\.?)\s+(\S.*)$/.exec(line)
    if (m) {
      const ref = m[1].replace(/\.$/, '')
      const text = m[2].replace(/\s{2,}/g, ' ').trim()
      // Short top-level lines without a full stop are section titles ("734. Additional Turns").
      if (!ref.includes('.') && text.length < 60 && !/[.:]$/.test(text)) heading = `${ref} ${text}`
      out.push([ref, text, heading])
    } else if (out.length && line.trim() && !/^\s*(\d+|Riftbound (Core|Tournament) Rules.*|Last Updated.*)\s*$/i.test(line)) {
      out.at(-1)[1] += ' ' + line.trim().replace(/\s{2,}/g, ' ')
    }
  }
  return out
}

async function rulesDocs() {
  const hub = await (await fetch(HUB, { headers: UA })).text()
  // Each document's download link sits right after its description on the hub page.
  const links = [...hub.matchAll(/href="(https:\/\/cmsassets\.rgpub\.io\/[^"]+?\.pdf)/g)].map((m) => m[1])
  const unique = [...new Set(links)]
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rb-rules-'))
  const docs = {}
  for (const url of unique) {
    const pdf = path.join(tmp, path.basename(url))
    fs.writeFileSync(pdf, Buffer.from(await (await fetch(url, { headers: UA })).arrayBuffer()))
    const text = execFileSync('pdftotext', [pdf, '-'], { maxBuffer: 64 << 20 }).toString()
    const layout = execFileSync('pdftotext', ['-layout', pdf, '-'], { maxBuffer: 64 << 20 }).toString()
    const head = text.slice(0, 400)
    if (/Core Rules/i.test(head)) [docs.core, docs.coreEntries] = [tidy(text), entries(layout)]
    else if (/Tournament Rules/i.test(head)) [docs.tournament, docs.tournamentEntries] = [tidy(text), entries(layout)]
  }
  fs.rmSync(tmp, { recursive: true, force: true })
  if (!docs.core) throw new Error(`No Core Rules PDF found on ${HUB}`)
  return docs
}

const plain = (html) => String(html ?? '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '').replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').trim()

async function riftcodexCards() {
  const out = []
  for (let page = 1, pages = 1; page <= pages; page++) {
    const body = await (await fetch(`https://api.riftcodex.com/cards?size=100&page=${page}`)).json()
    pages = body.pages
    for (const c of body.items) {
      const m = c.metadata ?? {}
      if (m.alternate_art || m.overnumbered || m.signature) continue
      out.push({
        name: c.name.replace(/\s*\([^)]*\)\s*$/, ''),
        type: [c.classification?.supertype, c.classification?.type].filter(Boolean).join(' '),
        domains: c.classification?.domain ?? [],
        cost: c.attributes?.energy ?? null,
        power: c.attributes?.power ?? null,
        might: c.attributes?.might ?? null,
        tags: c.tags ?? [],
        set: c.set?.set_id ?? '',
        text: plain(c.text?.plain),
      })
    }
  }
  return out
}

// Riot's gallery, for sets riftcodex doesn't have yet (same rule as lib/cards.js).
async function galleryCards(knownSets) {
  const out = []
  for (let from = 0, total = Infinity; from < total;) {
    const body = await (await fetch(`https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US&from=${from}&limit=200`)).json()
    total = body.metadata?.totalItems ?? 0
    const items = body.data ?? []
    if (!items.length) break
    from += items.length
    for (const g of items) {
      const set = String(g.set?.value?.id ?? '').toUpperCase()
      if (!set || knownSets.has(set)) continue
      const num = String(g.id).toLowerCase().split('-')[1] ?? ''
      if (/a$/.test(num) || num.startsWith('sp') || String(g.id).includes('star')) continue
      const type = g.cardType?.type?.[0]?.label ?? ''
      const tags = g.tags?.tags ?? []
      let name = String(g.name ?? '').trim()
      if (type === 'Legend' && tags.at(-1) && !name.startsWith(`${tags.at(-1)} `)) name = `${tags.at(-1)} - ${name}`
      else if (g.subtitle) name = `${name} - ${g.subtitle}`
      const cost = Number(g.energy?.value?.id)
      out.push({ name, type: g.subtitle ? `Champion ${type}` : type, domains: (g.domain?.values ?? []).map((d) => d.label), cost: Number.isFinite(cost) ? cost : null, power: null, might: Number(g.might?.value?.id) || null, tags, set, text: plain(g.text?.richText?.body) })
    }
  }
  return out
}

const docs = await rulesDocs()
const main = await riftcodexCards()
const extra = await galleryCards(new Set(main.map((c) => c.set.toUpperCase())))
// One entry per card name (reprints across sets share their text).
const byKey = new Map()
for (const c of [...main, ...extra]) if (!byKey.has(nameKey(c.name))) byKey.set(nameKey(c.name), c)
const cards = [...byKey.values()].sort((a, b) => a.name.localeCompare(b.name))

fs.mkdirSync(OUT, { recursive: true })
fs.writeFileSync(path.join(OUT, 'core-rules.txt'), docs.core)
if (docs.tournament) fs.writeFileSync(path.join(OUT, 'tournament-rules.txt'), docs.tournament)
fs.writeFileSync(path.join(OUT, 'cards.json'), JSON.stringify(cards))
fs.writeFileSync(SEARCH_OUT, JSON.stringify({
  coreUpdated: /Last Updated:\s*([0-9-]+)/.exec(docs.core)?.[1] ?? '',
  core: docs.coreEntries,
  tournament: docs.tournamentEntries ?? [],
  cards: cards.map((c) => [c.name, c.type, c.text]),
}))
const updated = /Last Updated:\s*([0-9-]+)/.exec(docs.core)?.[1] ?? 'unknown'
fs.writeFileSync(path.join(OUT, 'version.json'), JSON.stringify({ builtAt: new Date().toISOString(), coreRulesUpdated: updated, cards: cards.length }, null, 2) + '\n')
console.log(`Core Rules (updated ${updated}): ${docs.core.length} chars; Tournament Rules: ${docs.tournament?.length ?? 0} chars; ${cards.length} cards -> ${OUT}; search: ${docs.coreEntries.length} + ${docs.tournamentEntries?.length ?? 0} rules -> ${SEARCH_OUT}`)
