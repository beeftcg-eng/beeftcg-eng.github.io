#!/usr/bin/env bash
# Copy the players' points app into the GitHub Pages site repo (beeftcg-eng.github.io/points/).
# Review, then commit and push from that repo yourself.
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
SITE="${1:-$HOME/Desktop/beeftcg-eng.github.io}"
mkdir -p "$SITE/points"
cp "$HERE"/points/{index.html,app.js,app.css,sw.js,icon.svg,icon-192.png,icon-512.png,icon-maskable.png,apple-touch-icon.png,manifest.webmanifest} "$SITE/points/"
cp "$HERE/public/relay.js" "$SITE/points/relay.js"
cp "$HERE/public/rulesearch.js" "$HERE/public/rules-data.json" "$SITE/points/"
echo "Copied to $SITE/points. Now: cd \"$SITE\" && git add points && git commit -m 'Riftbound Points' && git push"
