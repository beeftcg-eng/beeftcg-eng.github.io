#!/usr/bin/env bash
# Publish this commit as a Riftcast update: the zip and latest.json go to the public site
# (beeftcg-eng.github.io/riftcast/), where every Riftcast's "Check for updates" finds them.
# Bump package.json's version and commit first.  Usage: scripts/publish-release.sh "What's new"
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
SITE="${SITE:-$HOME/Desktop/beeftcg-eng.github.io}"
NOTES="${1:-}"
cd "$HERE"
[ -z "$(git status --porcelain)" ] || { echo "Commit your changes first (the zip is made from the last commit)."; exit 1; }
VERSION="$(node -p "require('./package.json').version")"
OUT="$SITE/riftcast"
mkdir -p "$OUT"
rm -f "$OUT"/riftcast-*.zip
ZIP="riftcast-$VERSION.zip"
git archive --format=zip -o "$OUT/$ZIP" HEAD
cp "$OUT/$ZIP" "$OUT/riftcast.zip"           # a stable link for first installs
cp "$OUT/$ZIP" "$HOME/Desktop/riftcast.zip"   # the copy to send by hand
SHA="$(sha256sum "$OUT/$ZIP" | cut -d' ' -f1)"
SIZE="$(stat -c %s "$OUT/$ZIP")"
VERSION="$VERSION" ZIP="$ZIP" SHA="$SHA" SIZE="$SIZE" NOTES="$NOTES" node -e '
const e = process.env
const info = { version: e.VERSION, notes: e.NOTES, zip: e.ZIP, sha256: e.SHA, size: Number(e.SIZE), date: new Date().toISOString().slice(0, 10) }
require("fs").writeFileSync(process.argv[1], JSON.stringify(info, null, 2) + "\n")
' "$OUT/latest.json"
echo "Riftcast $VERSION ready in $OUT ($SIZE bytes). Now: cd \"$SITE\" && git add riftcast && git commit -m 'Riftcast $VERSION' && git push"
