// Riftcast ↔ Rift Atlas connector. Runs inside a play.riftatlas.com game tab (started from the
// "Riftcast: link Rift Atlas" bookmark) and reports public game events to Riftcast:
//   - cards played (from the match log), with who played them
//   - player names, legends, and points
// It only reads what is visible on the board and in the log; it never reads anyone's hand.
;(() => {
  if (window.__riftcast) {
    window.__riftcast.flash('Already linked to Riftcast')
    return
  }
  const BASE = (() => {
    try {
      return new URL(document.currentScript.src).origin
    } catch {
      return 'http://localhost:7420'
    }
  })()
  const SEEN_KEY = 'riftcast-seen'
  const seen = new Set(JSON.parse(sessionStorage.getItem(SEEN_KEY) ?? '[]'))
  let stopped = false
  let lastScore = ''
  let lastPlayers = ''
  let ok = null

  // ---- Badge ----
  const badge = document.createElement('div')
  badge.style.cssText = 'position:fixed;left:10px;bottom:10px;z-index:2147483647;padding:5px 10px;border-radius:14px;font:600 12px system-ui,sans-serif;color:#fff;background:#1f2b45;border:1px solid #e8b84a;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.5)'
  badge.title = 'Click to stop sending this game to Riftcast'
  badge.textContent = 'Riftcast: linking…'
  badge.onclick = () => {
    stopped = true
    observer.disconnect()
    clearInterval(beat)
    badge.remove()
    delete window.__riftcast
  }
  document.body.appendChild(badge)
  let flashTimer = null
  const setBadge = (text, good) => {
    badge.textContent = text
    badge.style.borderColor = good ? '#4fc27a' : '#e0565b'
  }
  const flash = (text) => {
    const before = badge.textContent
    badge.textContent = text
    clearTimeout(flashTimer)
    flashTimer = setTimeout(() => (badge.textContent = before), 2500)
  }

  async function send(body) {
    if (stopped) return
    try {
      const res = await fetch(`${BASE}/api/riftatlas/event`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...body, page: location.pathname }) })
      const out = await res.json()
      if (!ok) setBadge('Riftcast: linked ●', true)
      ok = true
      return out
    } catch {
      ok = false
      setBadge("Riftcast: can't reach Riftcast. Is it running? (allow local access if Chrome asks)", false)
    }
  }

  // ---- Reading the page ----

  function players() {
    const out = {}
    for (const t of document.querySelectorAll('[data-player-identity-trigger]')) {
      const role = t.dataset.playerIdentityTrigger === 'opponent' ? 'opponent' : 'self'
      const nameEl = t.querySelector('[data-identity-player-name]') ?? t.parentElement?.querySelector('[data-identity-player-name]')
      const label = t.getAttribute('aria-label')?.replace(/ profile and actions$/i, '')
      const name = (nameEl?.innerText || label || '').trim().split('\n')[0]
      if (name && !out[role]) out[role] = name
    }
    return out
  }

  function legends() {
    const out = {}
    for (const c of document.querySelectorAll('[data-drop-zone="legend"] [data-card-id], [data-card-id][data-drop-zone="legend"]')) {
      const role = c.closest('[data-zone-owner]')?.dataset.zoneOwner
      const name = c.querySelector('img[alt]')?.alt || c.getAttribute('alt')
      if (role && name && !out[role === 'self' ? 'self' : 'opponent']) out[role === 'self' ? 'self' : 'opponent'] = name
    }
    return out
  }

  function scores() {
    const out = {}
    // Your own track: buttons "Set your score to N". The opponent's: a "… score track" with the reached step marked.
    for (const el of document.querySelectorAll('[aria-label*="score to" i][data-active="true"]')) {
      const m = /score to (\d+)/i.exec(el.getAttribute('aria-label'))
      if (m) out[/\byour\b/i.test(el.getAttribute('aria-label')) ? 'self' : 'opponent'] = Number(m[1])
    }
    for (const track of document.querySelectorAll('[aria-label$="score track" i]')) {
      const role = /opponent/i.test(track.getAttribute('aria-label')) ? 'opponent' : 'self'
      if (role in out) continue
      const active = track.querySelector('[data-active="true"]')
      const n = active ? parseInt(active.innerText, 10) : NaN
      if (!Number.isNaN(n)) out[role] = n
    }
    return out
  }

  /** Whose board a just-played card is on: 'self', 'opponent', or null if it can't tell. */
  function boardOwner(name) {
    const roles = new Set()
    for (const c of document.querySelectorAll('[data-card-id]')) {
      if (c.querySelector('img[alt]')?.alt !== name) continue
      const zone = c.closest('[data-drop-zone]')?.dataset.dropZone ?? c.dataset.dropZone
      if (!zone || zone === 'hand') continue
      const role = c.closest('[data-zone-owner]')?.dataset.zoneOwner
      if (role) roles.add(role === 'self' ? 'self' : 'opponent')
    }
    return roles.size === 1 ? [...roles][0] : null
  }

  /** "Played X …" entries in the match log, oldest first, each with a stable id. */
  function plays() {
    const out = []
    const groups = [...document.querySelectorAll('[data-match-log-group="turn"]')]
    for (const g of groups) {
      const turn = g.dataset.turnNumber
      const label = g.querySelector('section[aria-label]')?.getAttribute('aria-label') ?? ''
      const turnPlayer = label.includes(',') ? label.slice(label.indexOf(',') + 1).trim() : null
      const counts = new Map()
      // The log lists newest first; read oldest first.
      for (const li of [...g.querySelectorAll('ul > li')].reverse()) {
        const text = li.innerText.replace(/\s+/g, ' ').trim()
        // The time runs straight into the word ("15:16Played …"), so no \b before it.
        if (!/(?:^|[^a-z])played\b/i.test(text) || /resolved/i.test(text)) continue
        const btn = li.querySelector('button[aria-label$=" card preview"]')
        if (!btn) continue // a face-down (hidden) card: nothing to show
        const name = btn.getAttribute('aria-label').replace(/ card preview$/, '')
        const art = li.querySelector('[data-card-art-source]')?.dataset.cardArtSource ?? ''
        const printing = /\/([A-Za-z0-9]+-[0-9]+[a-z*]*)\.(?:webp|png|jpe?g)/.exec(art)?.[1] ?? null
        const key = `${location.pathname}|${turn}|${g.dataset.turnPlayerId}|${text}`
        const k = (counts.get(key) ?? 0) + 1
        counts.set(key, k)
        out.push({ id: `${key}#${k}`, name, printing, turnPlayer })
      }
    }
    return out
  }

  // ---- Reporting ----

  let first = true
  function scan() {
    if (stopped) return
    const ps = players()
    const lg = legends()
    const pj = JSON.stringify([ps, lg])
    if (pj !== lastPlayers && (ps.self || ps.opponent)) {
      lastPlayers = pj
      send({ type: 'players', players: ps, legends: lg })
    }
    const sc = scores()
    const sj = JSON.stringify(sc)
    if (sj !== lastScore && Object.keys(sc).length) {
      lastScore = sj
      send({ type: 'score', ...sc, players: ps })
    }
    for (const p of plays()) {
      if (seen.has(p.id)) continue
      seen.add(p.id)
      // Plays already in the log when the link starts are history: don't replay them on stream.
      if (first) continue
      const role = boardOwner(p.name)
      send({ type: 'played', id: p.id, name: p.name, printing: p.printing, ownerRole: role, ownerName: role ? ps[role] : p.turnPlayer })
    }
    sessionStorage.setItem(SEEN_KEY, JSON.stringify([...seen].slice(-400)))
    first = false
  }

  let pending = null
  const observer = new MutationObserver(() => {
    if (pending) return
    pending = setTimeout(() => {
      pending = null
      scan()
    }, 250)
  })
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-active', 'aria-label'] })
  const beat = setInterval(() => send({ type: 'heartbeat', players: players(), legends: legends() }), 5000)

  window.__riftcast = { flash, scan }
  send({ type: 'hello', players: players(), legends: legends() }).then(() => scan())
})()
