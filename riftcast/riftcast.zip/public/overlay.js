// OBS Browser Source: draws the broadcast from the server's live state.
const $ = (sel, el = document) => el.querySelector(sel)
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c])
const img = (id) => `/img/${encodeURIComponent(id)}`

let state = null
let clockOffset = 0
let cards = new Map()
let lastSeq = null
let lastPoints = [null, null]
let lastXp = [null, null]
// The Level thresholds Unleashed cards print most.
const XP_LEVELS = [3, 6, 11, 16]
const xpLevel = (xp) => XP_LEVELS.filter((n) => xp >= n).pop() ?? 0
// XP shows once either player has some this game (most decks never use it).
const showXp = () => state.settings.showXp !== false && state.players.some((p) => (p.xp ?? 0) > 0)
let popTimer = null
let hideTimer = null
let leaveTimer = null

/** The card slides down toward the bottom of the screen as it fades out. */
function leave(spot) {
  if (spot.classList.contains('hidden')) return
  spot.classList.add('leaving')
  clearTimeout(leaveTimer)
  leaveTimer = setTimeout(() => {
    spot.classList.add('hidden')
    spot.classList.remove('leaving')
  }, 900)
}

async function loadCards() {
  try {
    const list = await (await fetch('/api/cards')).json()
    if (list.length) cards = new Map(list.map((c) => [c.id, c]))
  } catch {}
}

let loadedVersion = null
function connect() {
  const es = new EventSource('/api/events')
  es.onmessage = async (ev) => {
    const msg = JSON.parse(ev.data)
    // After a one-click update Riftcast restarts with new code: load the new version of this page too.
    if (msg.update?.version) {
      if (loadedVersion && loadedVersion !== msg.update.version) return location.reload()
      loadedVersion = msg.update.version
    }
    clockOffset = msg.serverNow - Date.now()
    if (cards.size !== msg.cardsStatus.count) await loadCards()
    state = msg.state
    render()
  }
  // EventSource reconnects by itself if the server restarts.
}

// One point from winning, and nobody has won yet.
function matchPoint(i) {
  const w = state.settings.winPoints, ps = state.players.map((p) => p.points)
  return w > 1 && ps[i] === w - 1 && !ps.some((p) => p >= w)
}

function renderPlayer(section, pl, i) {
  const s = state.settings
  const legend = cards.get(pl.legendId)
  const bf = cards.get(pl.battlefieldId)
  const winsNeeded = Math.ceil(s.bestOf / 2)
  const legendName = legend ? legend.name.replace(/\s*\([^)]*\)\s*$/, '') : ''
  section.innerHTML = `
    <div class="name-bar"><span class="name">${esc(pl.name)}</span>${pl.pronouns ? `<span class="pronouns">${esc(pl.pronouns)}</span>` : ''}</div>
    <div class="legend">${legend ? `<img src="${img(legend.id)}" alt=""><div class="caption">${esc(legendName)}</div>` : ''}</div>
    <div class="cam"></div>
    <div class="match-row">
      <div class="record"><div class="rec">${esc(pl.record)}</div>
        <div class="wins">${Array.from({ length: winsNeeded }, (_, k) => `<span class="win-pip ${k < pl.gameWins ? 'on' : ''}"></span>`).join('')}</div></div>
      <div class="battlefield ${bf ? '' : 'empty'}">${bf ? `<img src="${img(bf.id)}" alt="">` : ''}<div class="bf-name">${bf ? esc(bf.name.replace(/\s*\([^)]*\)\s*$/, '')) : 'Battlefield'}</div></div>
    </div>
    <div class="points ${matchPoint(i) ? 'match-point' : ''} ${showXp() ? 'with-xp' : ''}">
      ${matchPoint(i) ? '<div class="mp-badge">Match point</div>' : ''}
      <div class="num">${pl.points}</div>
      <div class="pips" style="grid-template-columns: repeat(${s.winPoints}, 1fr)">${Array.from({ length: s.winPoints }, (_, k) => `<span class="pip ${k < pl.points ? 'on' : ''}"></span>`).join('')}</div>
      ${showXp() ? `<div class="xp"><div class="xp-num">${pl.xp ?? 0}</div><div class="xp-lbl">${xpLevel(pl.xp ?? 0) ? `XP · Lv ${xpLevel(pl.xp ?? 0)}` : 'XP'}</div></div>` : ''}
    </div>`
  if (lastPoints[i] !== null && lastPoints[i] !== pl.points) {
    const num = $('.num', section)
    num.classList.add('bump')
    // Say how the point was scored (Conquer / Hold) when the point log knows.
    const d = pl.points - lastPoints[i]
    if (d > 0) {
      const entry = [...(state.pointLog ?? [])].reverse().find((e) => e.player === i && e.to === pl.points)
      const why = /conquer/i.test(entry?.reason ?? '') ? 'conquer' : /hold/i.test(entry?.reason ?? '') ? 'hold' : ''
      const tag = document.createElement('div')
      tag.className = `score-tag ${why}`
      tag.textContent = why === 'conquer' ? `⚔ Conquer +${d}` : why === 'hold' ? `🛡 Hold +${d}` : `+${d}`
      $('.points', section).appendChild(tag)
    }
  }
  lastPoints[i] = pl.points
  const xp = pl.xp ?? 0
  if (lastXp[i] !== null && lastXp[i] !== xp && $('.xp', section)) {
    const box = $('.xp', section)
    box.classList.add(xp > lastXp[i] ? 'bump' : 'dip')
    // Crossing a Level threshold switches those abilities on: call it out.
    if (xp > lastXp[i] && xpLevel(xp) > xpLevel(lastXp[i])) {
      box.classList.add('level-up')
      const tag = document.createElement('div')
      tag.className = 'score-tag xp-tag'
      tag.textContent = `★ Level ${xpLevel(xp)}`
      $('.points', section).appendChild(tag)
    }
  }
  lastXp[i] = xp
}

// Players only redraw when something about them changes, so images don't flicker every timer tick.
let lastPlayerJson = ['', '']
function render() {
  const s = state.settings
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(s.accent || '') ?? [, 'e8', 'b8', '4a']
  document.documentElement.style.setProperty('--accent', `#${m[1]}${m[2]}${m[3]}`)
  document.documentElement.style.setProperty('--accent-rgb', [m[1], m[2], m[3]].map((h) => parseInt(h, 16)).join(', '))
  document.body.classList.toggle('no-cams', !s.showCams)
  document.body.classList.toggle('no-owner', !s.showOwner)

  state.players.forEach((pl, i) => {
    const json = JSON.stringify([pl, s.winPoints, s.bestOf, cards.size, matchPoint(i), state.players.some((p) => p.points >= s.winPoints), showXp()])
    if (json !== lastPlayerJson[i]) {
      lastPlayerJson[i] = json
      renderPlayer($(`.player[data-player="${i}"]`), pl, i)
    }
  })

  $('.event-name').textContent = state.event.name
  $('.event-sub').textContent = [state.event.stage, state.event.location].filter(Boolean).join(' · ')
  $('.round').textContent = state.round.label || `Round ${state.round.current} of ${state.round.total}`
  tick()
  renderSpotlight()
}

function tick() {
  if (!state) return
  const t = state.timer
  const remaining = t.running ? Math.max(0, t.endsAt - (Date.now() + clockOffset)) : t.remainingMs
  const total = Math.ceil(remaining / 1000)
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const sec = total % 60
  const text = h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
  const el = $('.timer')
  $('.time', el).textContent = remaining <= 0 ? 'TIME' : text
  el.classList.toggle('paused', !t.running && remaining > 0)
  el.classList.toggle('low', remaining > 0 && remaining <= 5 * 60_000)
  el.classList.toggle('over', remaining <= 0)
}
setInterval(tick, 250)

// ---- Spotlight: pops big over the table, then settles into the dock ----

function rectIn(box, aspect) {
  // Largest rectangle of the card's aspect (w/h) that fits in box, centered, leaving room for the owner tag.
  const tag = state.settings.showOwner ? 40 : 0
  const availH = box.height - tag
  let w = box.width
  let h = w / aspect
  if (h > availH) {
    h = availH
    w = h * aspect
  }
  return { left: box.left + (box.width - w) / 2, top: box.top + (box.height - (h + tag)) / 2, width: w, height: h + tag }
}

function place(spot, r) {
  Object.assign(spot.style, { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` })
}

function dockRect(aspect) {
  const d = $('.dock').getBoundingClientRect()
  return rectIn({ left: d.left, top: d.top, width: d.width, height: d.height }, aspect)
}

function bigRect(aspect) {
  const t = $('.table').getBoundingClientRect()
  const pad = 70
  return rectIn({ left: t.left + pad, top: t.top + pad, width: t.width - pad * 2, height: t.height - pad * 2 }, aspect)
}

function renderSpotlight() {
  const sp = state.spotlight
  if (sp.seq === lastSeq) return
  const first = lastSeq === null
  lastSeq = sp.seq
  clearTimeout(popTimer)
  clearTimeout(hideTimer)
  const spot = $('#spot')
  const card = cards.get(sp.cardId)
  if (!card) {
    leave(spot)
    return
  }
  const aspect = card.orientation === 'landscape' ? 1039 / 744 : 744 / 1039
  const owner = sp.owner !== null ? state.players[sp.owner]?.name : ''
  $('.spot-owner', spot).textContent = owner ? owner : ''
  const image = $('.spot-img', spot)
  const settle = () => {
    spot.classList.remove('big')
    place(spot, dockRect(aspect))
  }
  const show = () => {
    const pop = state.settings.popSec > 0 && !first
    spot.style.transition = 'none'
    spot.classList.toggle('big', pop)
    place(spot, pop ? bigRect(aspect) : dockRect(aspect))
    spot.classList.remove('hidden')
    spot.classList.add('entering')
    void spot.offsetWidth
    spot.style.transition = ''
    spot.classList.remove('entering')
    if (pop) popTimer = setTimeout(settle, state.settings.popSec * 1000)
    if (state.settings.autoHideSec > 0) {
      // Counted from when the card appeared; it always gets a few seconds in the side panel after a pop.
      const secs = Math.max(state.settings.autoHideSec, pop ? state.settings.popSec + 3 : 0)
      hideTimer = setTimeout(() => leave(spot), secs * 1000)
    }
  }
  spot.classList.add('hidden')
  let shown = false
  const once = () => {
    if (shown || state.spotlight.seq !== sp.seq) return
    shown = true
    show()
  }
  image.onload = once
  image.onerror = once
  image.src = img(card.id)
  if (image.complete && image.naturalWidth) once()
}

loadCards().then(connect)
