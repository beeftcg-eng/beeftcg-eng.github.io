// OBS Browser Source for between matches: event, round clock, a message, the match that's up next
// and the round's tables from the linked Pairings bracket.
const $ = (sel, el = document) => el.querySelector(sel)
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c])
const img = (id) => `/img/${encodeURIComponent(id)}`
const MAX_TABLES = 24

let state = null
let pairings = null
let clockOffset = 0
let cards = new Map()
let lastKey = ''

async function loadCards() {
  try {
    const list = await (await fetch('/api/cards')).json()
    if (list.length) cards = new Map(list.map((c) => [c.id, c]))
  } catch {}
}

const shortName = (name) => String(name ?? '').replace(/\s*\([^)]*\)\s*$/, '')

function render() {
  const s = state.settings
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(s.accent || '') ?? [, 'e8', 'b8', '4a']
  document.documentElement.style.setProperty('--accent', `#${m[1]}${m[2]}${m[3]}`)
  document.documentElement.style.setProperty('--accent-rgb', [m[1], m[2], m[3]].map((h) => parseInt(h, 16)).join(', '))

  $('.event-name').textContent = state.event.name
  $('.event-sub').textContent = [state.event.stage, state.event.location].filter(Boolean).join(' · ')
  $('.message').textContent = s.breakMessage ?? ''
  const b = pairings?.bracket
  $('.round').textContent = b?.label || state.round.label || `Round ${state.round.current} of ${state.round.total}`
  tick()

  // Redraw the players and tables only when they change, so images don't flicker on every update.
  const key = JSON.stringify([state.players.map((p) => [p.name, p.record, p.legendId, p.gameWins]), cards.size, b?.tables, b?.label, pairings?.featured, s.breakShowTables])
  if (key === lastKey) return
  lastKey = key

  // Up next: the players loaded on stream (named, not the "Player 1" placeholders).
  const named = state.players.every((p) => p.name && !/^Player [12]$/.test(p.name))
  $('.feature').hidden = !named
  state.players.forEach((p, i) => {
    const legend = cards.get(p.legendId)
    $(`.fp.p${i}`).innerHTML = `
      <div class="legend">${legend ? `<img src="${img(legend.id)}" alt="">` : ''}</div>
      <div><div class="pname">${esc(p.name)}</div>
      <div class="pinfo">${[p.record && p.record !== '0-0' ? p.record : '', legend ? shortName(legend.name) : ''].filter(Boolean).map(esc).join(' · ')}</div></div>`
  })

  const tables = s.breakShowTables !== false && b?.tables?.length ? b.tables : null
  $('.tables').hidden = !tables
  if (!tables) return
  $('.tables-label').textContent = `${b.label || 'This round'} · Pairings`
  const list = $('.table-list')
  list.classList.toggle('one', tables.length <= 5)
  const result = (t) => {
    if (!t.p2) return 'Bye'
    if (t.result === 'p1' || t.result === 'p2') return `${t.p1Games ?? ''}${t.p1Games != null ? '–' : ''}${t.p2Games ?? ''}` || 'Done'
    if (t.result === 'draw') return 'Draw'
    if (t.result) return 'Done'
    return 'vs'
  }
  const who = (p, won) => (p ? `<span class="who ${won ? 'win' : ''}">${esc(p.name)}</span>${p.record ? `<span class="rec">${esc(p.record)}</span>` : ''}` : '<span class="who rec">—</span>')
  const row = (t) => `
    <div class="trow ${t.id === pairings.featured ? 'featured' : ''} ${t.result ? 'done' : ''}">
      <span class="tno">${t.table ?? ''}</span>
      <span class="a">${who(t.p1, t.result === 'p1')}</span>
      <span class="mid">${esc(result(t))}</span>
      <span>${who(t.p2, t.result === 'p2')}</span>
    </div>`
  // Show as many tables as fit on screen; the rest become "+N more tables".
  let shown = Math.min(tables.length, MAX_TABLES)
  const draw = () => {
    list.innerHTML = tables.slice(0, shown).map(row).join('') + (tables.length > shown ? `<div class="more">+${tables.length - shown} more tables</div>` : '')
  }
  draw()
  while (shown > 1 && list.scrollHeight > list.clientHeight + 1) {
    shown -= list.classList.contains('one') ? 1 : 2
    draw()
  }
}

function tick() {
  if (!state) return
  const t = state.timer
  const remaining = t.running ? Math.max(0, t.endsAt - (Date.now() + clockOffset)) : t.remainingMs
  const total = Math.ceil(remaining / 1000)
  const h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), sec = total % 60
  const text = h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
  const el = $('.timer')
  $('.time', el).textContent = remaining <= 0 ? 'TIME' : text
  el.classList.toggle('paused', !t.running && remaining > 0)
  el.classList.toggle('low', remaining > 0 && remaining <= 5 * 60_000)
  el.classList.toggle('over', remaining <= 0)
}
setInterval(tick, 250)

let loadedVersion = null
function connect() {
  const es = new EventSource('/api/events')
  es.onmessage = async (ev) => {
    const msg = JSON.parse(ev.data)
    // After a one-click update Riftcast restarts with new code: load the new version of this page too.
    if (msg.update?.version) {
      if (loadedVersion && loadedVersion !== msg.update.version) return location.reload()
      loadedVersion = msg.update.version
    }
    clockOffset = msg.serverNow - Date.now()
    if (cards.size !== msg.cardsStatus.count) await loadCards()
    state = msg.state
    pairings = msg.pairings
    render()
  }
}
loadCards().then(connect)
