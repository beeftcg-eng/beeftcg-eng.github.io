import { qrSvg } from '/qr.js'
// Control panel: everything the stream operator touches.
const $ = (sel, el = document) => el.querySelector(sel)
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)]
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c])
const img = (id) => `/img/${encodeURIComponent(id)}`
const baseName = (name) => name.replace(/\s*\([^)]*\)\s*$/, '')
const norm = (s) => String(s).toLowerCase().replace(/[’‘`]/g, "'").replace(/\s+-\s+|,\s*/g, ' ').replace(/[^a-z0-9' ]+/g, ' ').replace(/\s+/g, ' ').trim()
const TYPE_ORDER = ['Unit', 'Spell', 'Gear', 'Battlefield', 'Legend', 'Rune']

let state = null
let camera = null
let riftatlas = null
let phones = null
let pairings = null
let update = null
let cardsStatus = {}
let clockOffset = 0
let cards = new Map()

async function act(action) {
  try {
    const res = await fetch('/api/action', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(action) })
    const body = await res.json()
    if (!body.ok) setStatus(body.error, true)
  } catch (e) {
    setStatus(`Server unreachable: ${e.message}`, true)
  }
}

let statusTimer = null
function setStatus(text, isErr = false) {
  const el = $('#status')
  el.textContent = text
  el.classList.toggle('err', isErr)
  clearTimeout(statusTimer)
  if (isErr) statusTimer = setTimeout(() => setStatus(cardsLine()), 6000)
}
const cardsLine = () => cardsStatus.loading ? 'Downloading card list…' : cardsStatus.error ? cardsStatus.error : `${cardsStatus.count ?? 0} cards loaded`

async function loadCards() {
  try {
    const list = await (await fetch('/api/cards')).json()
    if (list.length) cards = new Map(list.map((c) => [c.id, c]))
  } catch {}
}

// Inputs are only written to while the operator isn't typing in them.
function setValue(el, value) {
  if (document.activeElement !== el) el.value = value ?? ''
}

function debounce(fn, ms) {
  let t
  return (...args) => {
    clearTimeout(t)
    t = setTimeout(() => fn(...args), ms)
  }
}

// ---- Top bar ----

const sendEvent = debounce(() => act({ type: 'setEvent', name: $('#eventName').value, stage: $('#eventStage').value, location: $('#eventLocation').value }), 350)
for (const id of ['eventName', 'eventStage', 'eventLocation']) $(`#${id}`).addEventListener('input', sendEvent)
const sendRound = debounce(() => act({ type: 'setRound', current: $('#roundCur').value, total: $('#roundTotal').value }), 350)
$('#roundCur').addEventListener('input', sendRound)
$('#roundTotal').addEventListener('input', sendRound)
$('#timerToggle').addEventListener('click', () => act({ type: 'timerToggle' }))
$('#timerReset').addEventListener('click', () => act({ type: 'timerReset', minutes: $('#timerMin').value }))
$('#clearBtn').addEventListener('click', () => act({ type: 'clear' }))
$('#newMatchBtn').addEventListener('click', () => {
  if (confirmTwice($('#newMatchBtn'))) act({ type: 'newMatch' })
})
for (const btn of $$('[data-act]')) btn.addEventListener('click', () => act(JSON.parse(btn.dataset.act)))

// A destructive button asks "Sure?" on the first click instead of a browser dialog (which would freeze an OBS dock).
function confirmTwice(btn) {
  if (btn.dataset.armed) {
    delete btn.dataset.armed
    btn.textContent = btn.dataset.label
    return true
  }
  btn.dataset.label = btn.textContent
  btn.dataset.armed = '1'
  btn.textContent = 'Sure? Click again'
  setTimeout(() => {
    if (btn.dataset.armed) {
      delete btn.dataset.armed
      btn.textContent = btn.dataset.label
    }
  }, 3000)
  return false
}

function tickTimer() {
  if (!state) return
  const t = state.timer
  const remaining = t.running ? Math.max(0, t.endsAt - (Date.now() + clockOffset)) : t.remainingMs
  const total = Math.ceil(remaining / 1000)
  const el = $('#timerText')
  el.textContent = remaining <= 0 ? 'TIME' : `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`
  el.classList.toggle('over', remaining <= 0)
}
setInterval(tickTimer, 250)

// ---- Settings ----

$('#settingsBtn').addEventListener('click', () => {
  for (const el of $$('[data-setting]')) {
    const v = state.settings[el.dataset.setting]
    if (el.type === 'checkbox') el.checked = !!v
    else el.value = v
  }
  $('#overlayUrl').textContent = `${location.origin}/overlay`
  $('#breakUrl').textContent = `${location.origin}/break`
  $('#settings').showModal()
})
for (const el of $$('[data-setting]')) {
  el.addEventListener('change', () => act({ type: 'settings', values: { [el.dataset.setting]: el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value) : el.value } }))
}
$('#refreshCards').addEventListener('click', () => fetch('/api/refreshCards', { method: 'POST' }))

// ---- Players ----

function playerSkeleton(section, i) {
  section.innerHTML = `
    <div class="side-tag">${i === 0 ? 'Left' : 'Right'} player</div>
    <div class="fields">
      <input class="pname" data-f="name" placeholder="Name">
      <input data-f="pronouns" placeholder="Pronouns">
      <input data-f="record" placeholder="Record">
    </div>
    <div class="score">
      <div class="points-ctl"><span class="label">Points</span>
        <button data-d="-1" title="Take a point away (${i === 0 ? 'A' : 'L'})">−</button><span class="big">0</span><button data-d="1" data-reason="conquer" class="conquer" title="Conquer: +1 (${i === 0 ? 'Q' : 'P'})">⚔</button><button data-d="1" data-reason="hold" class="hold" title="Hold: +1 (${i === 0 ? 'W' : 'O'})">🛡</button></div>
      <div class="wins-ctl"><span class="label">Games won</span>
        <button data-w="-1">−</button><b>0</b><button data-w="1">+</button></div>
    </div>
    <div class="battlefields"></div>
    <details class="deck">
      <summary>Decklist (optional: puts this player's cards first in search)</summary>
      <textarea placeholder="Paste the decklist here (Legend: / Champion: / MainDeck: / Battlefields: / Sideboard:, one &quot;3 Card Name&quot; per line)"></textarea>
      <div class="row"><button class="primary load">Load decklist</button><button class="danger clear">Clear deck</button></div>
      <div class="unknown"></div>
    </details>
    <div class="grid"></div>`

  const send = debounce((field, value) => act({ type: 'setPlayer', player: i, [field]: value }), 350)
  for (const input of $$('[data-f]', section)) input.addEventListener('input', () => send(input.dataset.f, input.value))
  for (const b of $$('[data-d]', section)) b.addEventListener('click', () => act({ type: 'points', player: i, delta: Number(b.dataset.d), ...(b.dataset.reason ? { reason: b.dataset.reason } : {}) }))
  for (const b of $$('[data-w]', section)) b.addEventListener('click', () => act({ type: 'gameWin', player: i, delta: Number(b.dataset.w) }))
  $('.load', section).addEventListener('click', () => act({ type: 'loadDeck', player: i, text: $('textarea', section).value }))
  $('.clear', section).addEventListener('click', (e) => {
    if (confirmTwice(e.currentTarget)) act({ type: 'clearDeck', player: i })
  })
  section.addEventListener('click', (e) => {
    const tile = e.target.closest('[data-show]')
    if (tile) act({ type: 'show', cardId: tile.dataset.show, player: i })
    const bf = e.target.closest('[data-bf]')
    if (bf) act({ type: 'setPlayer', player: i, battlefieldId: bf.classList.contains('on') ? null : bf.dataset.bf })
  })
}

function sortEntries(entries) {
  return entries
    .map((e) => ({ ...e, card: cards.get(e.cardId) }))
    .filter((e) => e.card)
    .sort((a, b) => {
      const champ = (c) => (c.supertype === 'Champion' ? 0 : 1)
      return champ(a.card) - champ(b.card) ||
        TYPE_ORDER.indexOf(a.card.category) - TYPE_ORDER.indexOf(b.card.category) ||
        (a.card.cost ?? 99) - (b.card.cost ?? 99) ||
        a.card.name.localeCompare(b.card.name)
    })
}

function tile(card, count, liveId) {
  return `<button class="tile ${card.id === liveId ? 'live' : ''}" data-show="${card.id}" title="${esc(card.name)}">
    <img loading="lazy" class="${card.orientation}" src="${img(card.id)}" alt="">${count > 1 ? `<span class="cnt">${count}</span>` : ''}<span class="nm">${esc(baseName(card.name))}</span></button>`
}

const lastGridKey = ['', '']
function renderPlayer(section, pl, i) {
  setValue($('[data-f="name"]', section), pl.name)
  setValue($('[data-f="pronouns"]', section), pl.pronouns)
  setValue($('[data-f="record"]', section), pl.record)
  $('.points-ctl .big', section).textContent = pl.points
  $('.wins-ctl b', section).textContent = pl.gameWins
  // The decklist box keeps what the operator pasted until a deck is actually loaded (or cleared).
  const ta = $('textarea', section)
  if (ta.dataset.loaded !== pl.deckText) {
    ta.dataset.loaded = pl.deckText
    if (document.activeElement !== ta) ta.value = pl.deckText
  }

  const key = JSON.stringify([pl.legendId, pl.battlefieldIds, pl.battlefieldId, pl.main, pl.sideboard, pl.unknown, state.spotlight.cardId, cards.size])
  if (key === lastGridKey[i]) return
  lastGridKey[i] = key

  const legend = cards.get(pl.legendId)
  const bfs = pl.battlefieldIds.map((id) => cards.get(id)).filter(Boolean)
  $('.battlefields', section).innerHTML = bfs.length || legend
    ? `<span class="label">Battlefield this game</span>` +
      bfs.map((c) => `<button class="bf-btn ${c.id === pl.battlefieldId ? 'on' : ''}" data-bf="${c.id}"><img src="${img(c.id)}" alt="">${esc(baseName(c.name))}</button>`).join('')
    : ''
  const deck = $('details.deck', section)
  const hasDeck = pl.main.length > 0 || legend
  $('.unknown', section).textContent = pl.unknown.length ? `Not recognised (use the search box for these): ${pl.unknown.join(' · ')}` : ''

  const live = state.spotlight.cardId
  const top = [legend, ...bfs].filter(Boolean)
  const main = sortEntries(pl.main)
  const side = sortEntries(pl.sideboard)
  $('.grid', section).innerHTML = hasDeck
    ? [
        top.length ? `<h4>Legend & battlefields</h4>${top.map((c) => tile(c, 1, live)).join('')}` : '',
        main.length ? `<h4>Main deck (${main.reduce((n, e) => n + e.count, 0)})</h4>${main.map((e) => tile(e.card, e.count, live)).join('')}` : '',
        side.length ? `<h4>Sideboard</h4>${side.map((e) => tile(e.card, e.count, live)).join('')}` : '',
      ].join('')
    : ''
  if (hasDeck && !pl.unknown.length) deck.open = false
  if (pl.unknown.length) deck.open = true
}

// ---- Search: any card in the game. Decklists are optional; they only rank their cards first and know who played them ----

let results = [] // [{ card, owner }] where owner is 0, 1 or null
let sel = 0
let owner = 0 // who the next card from search is shown for: 0 left, 1 right, null nobody
const OWNER_CYCLE = [0, 1, null]
let uniqueCards = [] // one card per name, regular printing preferred
let uniqueSize = -1
// Search ignores apostrophes too, so "khazix" finds Kha'Zix.
const searchKey = (name) => norm(baseName(name)).replace(/'/g, '')

function buildUnique() {
  if (uniqueSize === cards.size) return
  uniqueSize = cards.size
  const byName = new Map()
  for (const card of cards.values()) {
    if (card.category === 'Rune') continue
    const key = searchKey(card.name)
    const prev = byName.get(key)
    if (!prev || (prev.card.special && !card.special)) byName.set(key, { card, key, words: key.split(' ') })
  }
  uniqueCards = [...byName.values()]
}

/** Lower is better; -1 = no match. Every typed word must start a word of the name, or appear inside it. */
function matchScore(entry, q, tokens) {
  if (entry.key === q) return 0
  if (entry.key.startsWith(q)) return 1
  let allPrefix = true
  for (const t of tokens) {
    if (entry.words.some((w) => w.startsWith(t))) continue
    allPrefix = false
    if (t.length < 3 || !entry.key.includes(t)) return -1
  }
  return allPrefix ? 2 : 3
}

/** Which player's decklist has this card, if exactly one does. */
function deckOwner(cardKey) {
  const owners = state.players
    .map((pl, i) => ([pl.legendId, ...pl.battlefieldIds, ...pl.main.map((e) => e.cardId), ...pl.sideboard.map((e) => e.cardId)]
      .some((id) => cards.has(id) && searchKey(cards.get(id).name) === cardKey) ? i : -1))
    .filter((i) => i >= 0)
  return owners.length === 1 ? owners[0] : undefined
}

function runSearch() {
  buildUnique()
  const q = norm($('#search').value).replace(/'/g, '')
  if (!q) {
    results = (state?.recent ?? []).map((r) => ({ card: cards.get(r.cardId), owner: r.owner, recent: true })).filter((r) => r.card)
    sel = 0
    $('#resultsHead').textContent = results.length ? 'Recently shown (click to show again)' : 'Type a card name above. Any Riftbound card works, no decklist needed.'
    return renderResults()
  }
  const tokens = q.split(' ')
  const hits = []
  for (const entry of uniqueCards) {
    const s = matchScore(entry, q, tokens)
    if (s < 0) continue
    const fromDeck = deckOwner(entry.key)
    // Cards in a loaded decklist rank first within the same match quality.
    hits.push({ card: entry.card, deckOwner: fromDeck, rank: s * 2 + (fromDeck === undefined ? 1 : 0) })
  }
  hits.sort((a, b) => a.rank - b.rank || a.card.name.length - b.card.name.length || a.card.name.localeCompare(b.card.name))
  results = hits.slice(0, 18).map((h) => ({ card: h.card, owner: h.deckOwner }))
  sel = 0
  $('#resultsHead').textContent = results.length ? `${hits.length} match${hits.length === 1 ? '' : 'es'}: Enter shows the highlighted one, ↑/↓ to pick` : 'No card matches that.'
  renderResults()
}

/** Owner a result goes on screen with: its decklist's player, its recorded player, or the "Played by" pick. */
function ownerFor(r) {
  return r.owner !== undefined ? r.owner : owner
}

function renderResults() {
  const live = state?.spotlight.cardId
  $('#results').innerHTML = results.map((r, k) => {
    const o = ownerFor(r)
    return `<button class="tile ${k === sel ? 'sel' : ''} ${r.card.id === live ? 'live' : ''}" data-k="${k}" title="${esc(r.card.name)}">
      <img class="${r.card.orientation}" src="${img(r.card.id)}" alt="">
      ${o !== null && state ? `<span class="who p${o}">${esc(state.players[o].name)}</span>` : ''}
      <span class="nm">${esc(baseName(r.card.name))}</span></button>`
  }).join('')
}

function renderOwner() {
  for (const b of $$('.owner-pick [data-owner]')) {
    const value = b.dataset.owner === 'none' ? null : Number(b.dataset.owner)
    b.classList.toggle('on', value === owner)
    if (value !== null && state) b.textContent = state.players[value].name || (value === 0 ? 'Left' : 'Right')
  }
}

function setOwner(o) {
  owner = o
  renderOwner()
  renderResults()
}

function showResult(k) {
  const r = results[k]
  if (!r) return
  const o = ownerFor(r)
  act({ type: 'show', cardId: r.card.id, ...(o !== null ? { player: o } : {}) })
  $('#search').value = ''
  runSearch()
}

for (const b of $$('.owner-pick [data-owner]')) b.addEventListener('click', () => setOwner(b.dataset.owner === 'none' ? null : Number(b.dataset.owner)))

$('#search').addEventListener('input', runSearch)
$('#search').addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault()
    if (!results.length) return
    sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + results.length) % results.length
    renderResults()
  } else if (e.key === 'Enter') {
    e.preventDefault()
    showResult(sel)
  } else if (e.key === 'Tab') {
    e.preventDefault()
    setOwner(OWNER_CYCLE[(OWNER_CYCLE.indexOf(owner) + (e.shiftKey ? 2 : 1)) % 3])
  } else if (e.key === 'Escape') {
    e.preventDefault()
    if ($('#search').value) {
      $('#search').value = ''
      runSearch()
    } else {
      act({ type: 'clear' })
    }
  }
})
$('#results').addEventListener('mousedown', (e) => {
  const tile = e.target.closest('[data-k]')
  if (tile) {
    e.preventDefault()
    showResult(Number(tile.dataset.k))
  }
})


// ---- Hotkeys (only when not typing) ----

document.addEventListener('keydown', (e) => {
  const typing = ['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName) || $('#settings').open
  if (typing || e.ctrlKey || e.metaKey || e.altKey) return
  const k = e.key.toLowerCase()
  const keys = {
    '/': () => $('#search').focus(),
    escape: () => act({ type: 'clear' }),
    q: () => act({ type: 'points', player: 0, delta: 1, reason: 'conquer' }),
    w: () => act({ type: 'points', player: 0, delta: 1, reason: 'hold' }),
    a: () => act({ type: 'points', player: 0, delta: -1 }),
    p: () => act({ type: 'points', player: 1, delta: 1, reason: 'conquer' }),
    o: () => act({ type: 'points', player: 1, delta: 1, reason: 'hold' }),
    l: () => act({ type: 'points', player: 1, delta: -1 }),
    t: () => act({ type: 'timerToggle' }),
  }
  if (keys[k]) {
    e.preventDefault()
    keys[k]()
  }
})

// ---- Render ----

function setAccent(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '') ?? [, 'e8', 'b8', '4a']
  document.documentElement.style.setProperty('--accent', `#${m[1]}${m[2]}${m[3]}`)
  document.documentElement.style.setProperty('--accent-rgb', [m[1], m[2], m[3]].map((h) => parseInt(h, 16)).join(', '))
}

function render() {
  setValue($('#eventName'), state.event.name)
  setValue($('#eventStage'), state.event.stage)
  setValue($('#eventLocation'), state.event.location)
  setValue($('#roundCur'), state.round.current)
  setValue($('#roundTotal'), state.round.total)
  setValue($('#timerMin'), state.timer.durationMin)
  $('#timerToggle').textContent = state.timer.running ? 'Pause' : 'Start'
  tickTimer()
  setAccent(state.settings.accent)

  const now = cards.get(state.spotlight.cardId)
  $('#nowImg').src = now ? img(now.id) : ''
  $('#nowName').textContent = now ? `${baseName(now.name)}${state.spotlight.owner !== null ? ` — ${state.players[state.spotlight.owner].name}` : ''}` : 'Nothing'
  renderCamera()
  renderRiftAtlas()
  renderPhones()
  renderUpdate()
  renderPairings()

  state.players.forEach((pl, i) => renderPlayer($(`.player[data-player="${i}"]`), pl, i))
  renderOwner()
  if (!$('#search').value) runSearch()
  else renderResults()
  $('#cardsInfo').textContent = `Card list: ${cardsLine()}${cardsStatus.updatedAt ? `, updated ${new Date(cardsStatus.updatedAt).toLocaleString()}` : ''}.`
  if (!$('#status').classList.contains('err')) setStatus(cardsLine())
}

// ---- Updates ----

function renderUpdate() {
  const u = update
  const btn = $('#updateBtn')
  btn.hidden = !u?.available && u?.state !== 'installing' && u?.state !== 'installed'
  btn.textContent = u?.state === 'installing' ? '⬆ Updating…' : u?.state === 'installed' ? '⬆ Restart to finish' : `⬆ Update to ${u?.latest?.version ?? ''}`
  if (!u) return
  const when = u.checkedAt ? ` Checked ${new Date(u.checkedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}.` : ''
  $('#updateInfo').textContent =
    u.state === 'checking' ? `Riftcast ${u.version}. Checking…`
      : u.state === 'installing' ? `Downloading and installing Riftcast ${u.latest?.version}…`
        : u.state === 'installed' ? (u.autoRestart ? `Installed ${u.latest?.version}. Restarting…` : `Installed ${u.latest?.version}. Close the Riftcast window and start it again to finish.`)
          : u.error ? `Riftcast ${u.version}. ⚠ ${u.error}`
            : u.available ? `Riftcast ${u.version}. Version ${u.latest.version} is ready to install.${when}`
              : `Riftcast ${u.version} is up to date.${when}`
  $('#updateNotes').hidden = !(u.available && u.latest?.notes)
  $('#updateNotes').textContent = u.latest?.notes ? `What's new: ${u.latest.notes}` : ''
  $('#updateInstall').hidden = !u.available || u.state === 'installing' || u.state === 'installed'
  $('#updateInstall').textContent = `Install ${u.latest?.version ?? 'update'}`
  $('#updateCheck').disabled = u.state === 'checking' || u.state === 'installing'
}

async function installUpdate() {
  setStatus(`Installing Riftcast ${update?.latest?.version}…`)
  try {
    const out = await (await fetch('/api/update/install', { method: 'POST' })).json()
    if (!out.ok) return setStatus(out.error || 'Update failed', true)
    setStatus(out.autoRestart ? 'Update installed. Riftcast is restarting, this page reloads by itself.' : 'Update installed. Close the Riftcast window and start it again.')
  } catch {
    setStatus('Riftcast is restarting…')
  }
}

$('#updateCheck').addEventListener('click', () => fetch('/api/update/check', { method: 'POST' }))
$('#updateInstall').addEventListener('click', installUpdate)
$('#updateBtn').addEventListener('click', () => {
  $('#settingsBtn').click()
  $('#updateInfo').scrollIntoView({ block: 'center' })
})

// ---- Players' phones ----

const appLinkFor = (code) => `${phones?.appUrl ?? 'https://beeftcg-eng.github.io/points/'}#${code}`

function openPhones() {
  if (!state) return
  renderPhones(true)
  $('#phones').showModal()
}

function renderPhones(force = false) {
  const linked = phones?.linked ?? [false, false]
  const tableLinked = !!phones?.tableLinked
  const btn = $('#phonesBtn')
  const count = linked.filter(Boolean).length
  btn.textContent = tableLinked ? `📱 Table phone${count ? ` +${count}` : ''}` : count ? `📱 Phones ${count}/2` : '📱 Phones'
  btn.classList.toggle('on', tableLinked || count > 0)
  if (!$('#phones').open && !force) return
  if (!state) return
  const codes = state.phoneCodes ?? [null, null]
  const appUrl = phones?.appUrl ?? 'https://beeftcg-eng.github.io/points/'
  $('#appLink').href = appUrl
  $('#appLink').textContent = appUrl.replace(/^https?:\/\//, '').replace(/\/$/, '')
  const relay = phones?.relay ?? 'off'
  $('#relayLine').innerHTML = relay === 'online'
    ? '● Link service online.'
    : relay === 'connecting'
      ? '⚠ Connecting to the link service… Phones can link once this PC is online.'
      : '⚠ Link service off.'
  const key = JSON.stringify([codes, state.tableCode, appUrl, state.players.map((p) => p.name), linked, tableLinked])
  if (!force && key === renderPhones.last) return
  renderPhones.last = key
  const table = state.tableCode
  $('#phoneCards').innerHTML = `<div class="phone-card table">
      <div class="side">Table · one phone</div>
      <h3>${esc(state.players[0].name)} &amp; ${esc(state.players[1].name)}</h3>
      <div class="qr">${table ? qrSvg(appLinkFor(table)) : ''}</div>
      <div class="code">${esc(table ?? '')}</div>
      <div class="conn ${tableLinked ? 'on' : ''}">${tableLinked ? '● Table phone linked' : 'No table phone yet'}</div>
    </div>` + [0, 1].map((seat) => {
    const code = codes[seat]
    return `<div class="phone-card">
      <div class="side p${seat}">${seat === 0 ? 'Left' : 'Right'} player</div>
      <h3>${esc(state.players[seat].name)}</h3>
      <div class="qr">${code ? qrSvg(appLinkFor(code)) : ''}</div>
      <div class="code">${esc(code ?? '')}</div>
      <div class="conn ${linked[seat] ? 'on' : ''}">${linked[seat] ? '● Phone linked' : 'No phone linked yet'}</div>
    </div>`
  }).join('')
}

$('#phonesBtn').addEventListener('click', openPhones)
$('#newCodes').addEventListener('click', async (e) => {
  if (!confirmTwice(e.currentTarget)) return
  await fetch('/api/phones/new', { method: 'POST' })
  renderPhones(true)
})

// ---- Pairings ----

const RESULT_TEXT = { p1: (t) => `${t.p1.name} won`, p2: (t) => `${t.p2.name} won`, draw: () => 'Draw', double_loss: () => 'Double loss' }

function renderPairings(force = false) {
  const btn = $('#pairingsBtn')
  const b = pairings?.bracket
  btn.textContent = b ? `🏆 ${b.label || 'Pairings'}` : '🏆 Pairings'
  btn.classList.toggle('on', !!b)
  if (!$('#pairings').open && !force) return
  const linked = !!pairings?.id
  $('#pgLinkForm').hidden = linked
  $('#pgLinked').hidden = !linked
  $('#pgUnlink').hidden = !linked
  $('#pgErr').textContent = pairings?.error ? `⚠ ${pairings.error}` : ''
  if (!linked) return
  if (!b) {
    $('#pgName').textContent = pairings.loading ? 'Loading the bracket…' : 'Bracket not loaded'
    $('#pgSub').textContent = ''
    $('#pgTables').innerHTML = ''
    return
  }
  const statusText = { registration: 'Registration open', swiss: 'Swiss rounds', top_cut: 'Top cut', finished: 'Finished', cancelled: 'Cancelled' }[b.status] ?? b.status
  $('#pgName').textContent = b.name
  $('#pgSub').textContent = [b.store, `${b.players} players`, statusText, b.label].filter(Boolean).join(' · ')
  const key = JSON.stringify([b.tables, pairings.featured])
  if (!force && key === renderPairings.last) return
  renderPairings.last = key
  $('#pgTables').innerHTML = b.tables.length
    ? b.tables.map((t) => {
      const side = (p) => p ? `<span class="pg-p"><b>${esc(p.name)}</b><span class="hint">${esc([p.deck, p.record].filter(Boolean).join(' · '))}</span></span>` : '<span class="pg-p hint">Bye</span>'
      const result = t.result ? `${(RESULT_TEXT[t.result] ?? (() => t.result))(t)}${t.p1Games != null && t.p2Games != null ? ` ${t.p1Games}-${t.p2Games}` : ''}` : !t.p2 ? '' : t.status === 'disputed' ? '⚠ Disputed' : t.status === 'reported' ? 'Reported' : 'Playing'
      const on = pairings.featured === t.id
      return `<div class="pg-row ${on ? 'on' : ''}">
        <span class="pg-table">${t.table ? `T${t.table}` : ''}</span>
        ${side(t.p1)}<span class="pg-vs">vs</span>${side(t.p2)}
        <span class="pg-res hint">${esc(result)}</span>
        ${t.p2 ? `<button type="button" data-feature="${esc(t.id)}" class="${on ? 'on' : ''}">${on ? '📺 On stream' : '📺 Feature'}</button>` : '<span></span>'}
      </div>`
    }).join('')
    : '<p class="hint">No round paired yet. Tables show here once the organiser pairs round 1 in Pairings.</p>'
  for (const fb of $$('[data-feature]', $('#pgTables'))) fb.addEventListener('click', () => featureTable(fb))
}

async function pairingsCall(what, body = {}) {
  try {
    const res = await fetch(`/api/pairings/${what}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
    const out = await res.json()
    if (!out.ok) throw new Error(out.error)
    pairings = out.pairings
    renderPairings(true)
    return true
  } catch (e) {
    $('#pgErr').textContent = `⚠ ${e.message}`
    return false
  }
}

async function featureTable(btn) {
  // Featuring replaces the players on stream: ask twice unless nothing is on stream yet.
  const fresh = state.players.every((p, i) => p.name === `Player ${i + 1}` && !p.points)
  if (!fresh && pairings.featured !== btn.dataset.feature && !confirmTwice(btn)) return
  if (await pairingsCall('feature', { matchId: btn.dataset.feature })) setStatus('Feature match loaded from Pairings')
}

$('#pairingsBtn').addEventListener('click', () => {
  renderPairings(true)
  $('#pairings').showModal()
})
$('#pgLink').addEventListener('click', async () => {
  $('#pgErr').textContent = ''
  $('#pgLink').disabled = true
  if (await pairingsCall('link', { ref: $('#pgRef').value })) $('#pgRef').value = ''
  $('#pgLink').disabled = false
})
$('#pgRef').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault()
    $('#pgLink').click()
  }
})
$('#pgRefresh').addEventListener('click', () => pairingsCall('refresh'))
$('#pgUnlink').addEventListener('click', (e) => {
  if (confirmTwice(e.currentTarget)) pairingsCall('unlink')
})

// ---- Rift Atlas ----

$('#raBookmarklet').href = `javascript:(()=>{const s=document.createElement('script');s.src='${location.origin}/riftatlas.js?t='+Date.now();document.head.appendChild(s)})()`
$('#raBookmarklet').addEventListener('click', (e) => {
  e.preventDefault()
  setStatus('Drag that button to your bookmarks bar, then click it in a Rift Atlas game tab.')
})

function renderRiftAtlas() {
  const chip = $('#raChip')
  if (!riftatlas?.lastSeenAt) return (chip.style.display = 'none')
  chip.style.display = ''
  const p = riftatlas.players
  chip.textContent = riftatlas.connected ? `🎮 Rift Atlas: ${p?.self ?? '?'} vs ${p?.opponent ?? '?'}` : '🎮 Rift Atlas: not linked'
  chip.className = `cam-chip ${riftatlas.connected ? 'watching' : 'error'}`
  chip.title = riftatlas.connected
    ? `Following the Rift Atlas game${riftatlas.lastPlay ? `. Last card: ${riftatlas.lastPlay.name}` : ''}`
    : 'The Rift Atlas tab stopped reporting. Click the bookmark in the game tab again.'
}

// ---- Camera ----

const CHIP = { off: ['📷 Camera off', ''], watching: ['📷 Watching', 'watching'], error: ['📷 Camera problem', 'error'], setup: ['📷 Needs setup', 'busy'], building: ['📷 Learning cards…', 'busy'], connecting: ['📷 Connecting…', 'busy'] }

function renderCamera() {
  if (!camera) return
  const [text, cls] = CHIP[camera.phase] ?? ['📷 Camera', '']
  const chip = $('#camChip')
  chip.textContent = text
  chip.className = `cam-chip ${cls}`
  chip.title = camera.message
  const auto = $('#camAuto')
  auto.textContent = camera.config.auto ? 'Auto: on' : 'Auto: off'
  auto.classList.toggle('on', camera.config.auto)
  auto.style.display = camera.config.enabled ? '' : 'none'

  // Cards the camera wasn't sure about (or every card, with auto off): one click to show.
  const sug = camera.suggestions.filter((s) => cards.has(s.cardId) && s.cardId !== state.spotlight.cardId)
  $('#camSuggest').innerHTML = sug.length
    ? `<span class="label">Camera ${camera.config.auto ? "isn't sure" : 'spotted'}: click to show</span>` +
      sug.map((s) => {
        const options = [{ id: s.cardId, name: s.name }, ...s.alternatives.slice(0, 1)]
        return options.map((o, k) => `<button class="sug" data-sug="${o.id}" data-owner="${s.owner ?? ''}"><img src="${img(o.id)}" alt="">
          <span>${esc(baseName(o.name))}${k ? ' <small>(or)</small>' : ''}${s.owner !== null && s.owner !== undefined ? `<br><small>${esc(state.players[s.owner].name)}</small>` : ''}</span></button>`).join('') +
          `<button class="sug-x" data-dismiss="${s.cardId}" title="Not a card / ignore">✕</button>`
      }).join('')
    : ''

  // A card the camera put up: its runner-up guesses, in case it's wrong.
  const fix = $('#nowFix')
  const latest = state.spotlight.source === 'camera' ? camera.log.find((e) => e.type === 'shown' && e.cardId === state.spotlight.cardId) : null
  if (state.spotlight.source === 'riftatlas') return (fix.innerHTML = '🎮 from Rift Atlas')
  fix.innerHTML = latest
    ? `📷 by camera${latest.alternatives.length ? ' · wrong? ' + latest.alternatives.map((a) => `<button data-fix="${a.id}">${esc(baseName(a.name))}</button>`).join('') : ''}`
    : ''
}

$('#camAuto').addEventListener('click', () => fetch(`/api/camera/auto?on=${!camera?.config.auto}`))
$('#camSuggest').addEventListener('click', (e) => {
  const b = e.target.closest('[data-sug]')
  if (b) {
    const owner = b.dataset.owner === '' ? null : Number(b.dataset.owner)
    act({ type: 'show', cardId: b.dataset.sug, ...(owner !== null ? { player: owner } : {}) })
    const stored = findSuggestionFor(b.dataset.sug)
    if (stored) fetch('/api/camera/dismiss', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ cardId: stored }) })
  }
  const x = e.target.closest('[data-dismiss]')
  if (x) fetch('/api/camera/dismiss', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ cardId: x.dataset.dismiss }) })
})
// A suggestion is stored under its best guess; showing its alternative also clears it.
function findSuggestionFor(id) {
  return camera.suggestions.find((s) => s.cardId === id || s.alternatives.some((a) => a.id === id))?.cardId
}
$('#nowFix').addEventListener('click', (e) => {
  const b = e.target.closest('[data-fix]')
  if (b) act({ type: 'show', cardId: b.dataset.fix, ...(state.spotlight.owner !== null ? { player: state.spotlight.owner } : {}) })
})

$$('.player').forEach((section, i) => playerSkeleton(section, i))

let loadedVersion = null
function connect() {
  const es = new EventSource('/api/events')
  es.onmessage = async (ev) => {
    const msg = JSON.parse(ev.data)
    // After a one-click update Riftcast restarts with new code: load the new version of this page too.
    if (msg.update?.version) {
      if (loadedVersion && loadedVersion !== msg.update.version) return location.reload()
      loadedVersion = msg.update.version
    }
    clockOffset = msg.serverNow - Date.now()
    update = msg.update
    cardsStatus = msg.cardsStatus
    camera = msg.camera
    riftatlas = msg.riftatlas
    phones = msg.phones
    pairings = msg.pairings
    if (cards.size !== cardsStatus.count) await loadCards()
    state = msg.state
    render()
  }
  es.onerror = () => setStatus('Lost connection to Riftcast, retrying…', true)
}

loadCards().then(connect)
