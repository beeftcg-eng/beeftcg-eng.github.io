// Camera setup page: OBS connection, live view with what the tracker sees, drawing the zones.
const $ = (sel, el = document) => el.querySelector(sel)
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)]
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c])

let cam = null
let appState = null
let tool = null
let drag = null
let frameImg = new Image()
let frameLoaded = false

async function post(url, body) {
  const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body ?? {}) })
  return res.json()
}
const setConfig = (patch) => post('/api/camera/config', patch)
const setTracker = (patch) => setConfig({ tracker: patch })

// ---- Connection & switches ----

$('#connectBtn').addEventListener('click', async () => {
  const patch = { obsUrl: $('#obsUrl').value.trim() || 'ws://127.0.0.1:4455' }
  if ($('#obsPassword').value) patch.obsPassword = $('#obsPassword').value
  await setConfig(patch)
  $('#obsPassword').value = ''
  $('#connectBtn').textContent = 'Connecting…'
  try {
    const res = await (await fetch('/api/camera/sources')).json()
    if (!res.ok) throw new Error(res.error)
    const sel = $('#source')
    const current = cam?.config.source ?? ''
    sel.innerHTML = `<option value="">— pick the table camera —</option>` + res.sources.map((s) => `<option ${s === current ? 'selected' : ''}>${esc(s)}</option>`).join('')
    $('#connectBtn').textContent = `Connected: ${res.sources.length} sources`
  } catch (e) {
    $('#connectBtn').textContent = 'Connect & list sources'
    showPhase('error', e.message)
  }
})
$('#source').addEventListener('change', () => setConfig({ source: $('#source').value, enabled: !!$('#source').value || cam.config.enabled }))
$('#enabled').addEventListener('change', () => setConfig({ enabled: $('#enabled').checked }))
$('#auto').addEventListener('change', () => setConfig({ auto: $('#auto').checked }))
$('#resetBtn').addEventListener('click', () => fetch('/api/camera/reset'))
$('#fps').addEventListener('change', () => setConfig({ fps: Number($('#fps').value) }))
for (const el of $$('[data-t]')) el.addEventListener('change', () => setTracker({ [el.dataset.t]: Number(el.value) }))
$('#splitAxis').addEventListener('change', () => setTracker({ split: { ...cam.config.tracker.split, axis: $('#splitAxis').value } }))
$('#swapHalves').addEventListener('click', () => setTracker({ split: { ...cam.config.tracker.split, first: 1 - cam.config.tracker.split.first } }))
$('#clearIgnore').addEventListener('click', () => setTracker({ ignore: [] }))

/** Any photo (phones take JPEG) as a PNG at most 1920 wide, like the camera snapshots. */
async function asPng(file) {
  const bmp = await createImageBitmap(file)
  const scale = Math.min(1, 1920 / bmp.width)
  const c = document.createElement('canvas')
  c.width = Math.round(bmp.width * scale)
  c.height = Math.round(bmp.height * scale)
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height)
  return new Promise((resolve) => c.toBlob(resolve, 'image/png'))
}

async function sendPhoto(input, step) {
  const file = input.files[0]
  input.value = ''
  if (!file) return
  $('#photoResult').textContent = step === 'before' ? 'Reading the empty table…' : 'Looking for the card…'
  const res = await (await fetch(`/api/camera/testPhoto?step=${step}`, { method: 'POST', body: await asPng(file) })).json()
  if (!res.ok) $('#photoResult').textContent = res.error
  else if (step === 'before') $('#photoResult').textContent = 'Got the empty table. Now the photo with a card played.'
  else {
    const KIND = { show: 'Would show', unsure: 'Not sure, would suggest', moved: 'Moved card', ignored: 'Ignored' }
    $('#photoResult').textContent = res.events.length
      ? res.events.map((e) => `${KIND[e.type] ?? e.type}: ${e.name} (score ${e.score.toFixed(2)}, lead ${e.margin.toFixed(2)})`).join(' · ')
      : 'No new card found. Is the card size right, and the card inside the table area?'
  }
  frameLoaded = false
  refreshFrame(true)
}
$('#photoBefore').addEventListener('change', (e) => sendPhoto(e.target, 'before'))
$('#photoAfter').addEventListener('change', (e) => sendPhoto(e.target, 'after'))

// ---- Drawing tools ----

const HINTS = {
  region: 'Drag around the table (both playmats).',
  card: 'Drag tightly around one card lying upright.',
  ignore: 'Drag around a deck, trash pile, rune pool or score track.',
  split: "Click where the two players' halves meet.",
}
for (const b of $$('[data-tool]')) b.addEventListener('click', () => {
  tool = tool === b.dataset.tool ? null : b.dataset.tool
  for (const x of $$('[data-tool]')) x.classList.toggle('on', x.dataset.tool === tool)
  $('#toolHint').textContent = tool ? HINTS[tool] : ''
})

const canvas = $('#view')
function toFrac(ev) {
  const r = canvas.getBoundingClientRect()
  return { x: Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)), y: Math.min(1, Math.max(0, (ev.clientY - r.top) / r.height)) }
}
canvas.addEventListener('mousedown', (ev) => {
  if (!tool || !cam) return
  const p = toFrac(ev)
  if (tool === 'split') {
    const s = cam.config.tracker.split
    setTracker({ split: { ...s, at: s.axis === 'y' ? p.y : p.x } })
    return
  }
  drag = { a: p, b: p }
})
canvas.addEventListener('mousemove', (ev) => {
  if (!drag) return
  drag.b = toFrac(ev)
  draw()
})
window.addEventListener('mouseup', () => {
  if (!drag) return
  const r = { x: Math.min(drag.a.x, drag.b.x), y: Math.min(drag.a.y, drag.b.y), w: Math.abs(drag.a.x - drag.b.x), h: Math.abs(drag.a.y - drag.b.y) }
  drag = null
  if (r.w < 0.005 || r.h < 0.005) return draw()
  const t = cam.config.tracker
  if (tool === 'region') setTracker({ region: r })
  else if (tool === 'ignore') setTracker({ ignore: [...t.ignore, r] })
  else if (tool === 'card') {
    // Stored as the upright card's size; a card drawn sideways is turned back.
    const fs = cam.frameSize ?? { width: 16, height: 9 }
    let pw = r.w * fs.width, ph = r.h * fs.height
    if (pw > ph) [pw, ph] = [ph, pw]
    setTracker({ cardSize: { w: pw / fs.width, h: ph / fs.height } })
  }
})

// ---- Picture ----

function refreshFrame(force = false) {
  if (!cam?.frameSize && !force) return
  const img = new Image()
  img.onload = () => {
    frameImg = img
    frameLoaded = true
    draw()
  }
  img.src = `/api/camera/frame?t=${Date.now()}`
}
setInterval(() => {
  if (cam?.phase === 'watching') refreshFrame()
}, 700)

function draw() {
  const ctx = canvas.getContext('2d')
  const fs = cam?.frameSize
  $('#noFrame').style.display = frameLoaded ? 'none' : 'flex'
  if (!frameLoaded || !fs) return
  const W = Math.min(1600, fs.width)
  const H = Math.round((W * fs.height) / fs.width)
  if (canvas.width !== W || canvas.height !== H) {
    canvas.width = W
    canvas.height = H
  }
  ctx.drawImage(frameImg, 0, 0, W, H)
  const t = cam.config.tracker
  const rect = (r, stroke, fill, width = 2) => {
    ctx.lineWidth = width
    if (fill) {
      ctx.fillStyle = fill
      ctx.fillRect(r.x * W, r.y * H, r.w * W, r.h * H)
    }
    ctx.strokeStyle = stroke
    ctx.strokeRect(r.x * W, r.y * H, r.w * W, r.h * H)
  }
  const label = (text, x, y, color) => {
    ctx.font = '600 14px system-ui, sans-serif'
    const w = ctx.measureText(text).width + 8
    ctx.fillStyle = 'rgba(0,0,0,0.75)'
    ctx.fillRect(x, y - 17, w, 18)
    ctx.fillStyle = color
    ctx.fillText(text, x + 4, y - 3)
  }

  // Halves.
  const s = t.split
  const names = [appState?.players[0].name ?? 'Left', appState?.players[1].name ?? 'Right']
  const firstName = names[s.first], secondName = names[1 - s.first]
  ctx.setLineDash([8, 6])
  ctx.strokeStyle = '#ffffff'
  ctx.lineWidth = 2
  ctx.beginPath()
  if (s.axis === 'y') { ctx.moveTo(0, s.at * H); ctx.lineTo(W, s.at * H) } else { ctx.moveTo(s.at * W, 0); ctx.lineTo(s.at * W, H) }
  ctx.stroke()
  ctx.setLineDash([])
  const c0 = s.first === 0 ? '#5aa9ff' : '#ff8a5a', c1 = s.first === 0 ? '#ff8a5a' : '#5aa9ff'
  if (s.axis === 'y') {
    label(`${firstName}'s cards`, 10, 26, c0)
    label(`${secondName}'s cards`, 10, s.at * H + 26, c1)
  } else {
    label(`${firstName}'s cards`, 10, 26, c0)
    label(`${secondName}'s cards`, s.at * W + 10, 26, c1)
  }

  rect(t.region, '#e8b84a', null, 3)
  for (const z of t.ignore) rect(z, '#e0565b', 'rgba(224,86,91,0.25)')
  // The calibrated card size, drawn in the table area's corner.
  rect({ x: t.region.x + 0.01, y: t.region.y + t.region.h - t.cardSize.h - 0.015, w: t.cardSize.w, h: t.cardSize.h }, '#e8b84a', 'rgba(232,184,74,0.25)')
  label('card size', (t.region.x + 0.01) * W, (t.region.y + t.region.h - t.cardSize.h - 0.015) * H, '#e8b84a')

  for (const k of cam.debug?.registry ?? []) {
    rect(k.box, '#4fc27a')
    label(k.name.replace(/\s*\([^)]*\)\s*$/, ''), k.box.x * W, k.box.y * H, '#a9f0c2')
  }
  for (const c of cam.debug?.components ?? []) {
    if (!c.sizeOk) continue
    rect(c.box, '#ffffff', 'rgba(255,255,255,0.08)')
    const secs = Math.min(c.still, t.stableSec)
    label(`${c.label ? c.label.replace(/\s*\([^)]*\)\s*$/, '') + ' · ' : ''}${secs.toFixed(1)}/${t.stableSec}s`, c.box.x * W, (c.box.y + c.box.h) * H + 18, '#ffffff')
  }
  if (drag) rect({ x: Math.min(drag.a.x, drag.b.x), y: Math.min(drag.a.y, drag.b.y), w: Math.abs(drag.a.x - drag.b.x), h: Math.abs(drag.a.y - drag.b.y) }, '#ffffff', 'rgba(255,255,255,0.15)')
}

// ---- Status ----

function showPhase(phase, message) {
  const el = $('#phase')
  el.className = `phase ${phase}`
  el.textContent = message
}

const setVal = (el, v) => {
  if (document.activeElement !== el) el.value = v
}

function render() {
  const c = cam.config
  showPhase(cam.phase, `${cam.message}${cam.phase === 'watching' ? ` · ${cam.fps} pictures/s` : ''}`)
  setVal($('#obsUrl'), c.obsUrl)
  $('#obsPassword').placeholder = c.hasPassword ? '(saved)' : '(none)'
  if (c.source && ![...$('#source').options].some((o) => o.value === c.source)) $('#source').insertAdjacentHTML('beforeend', `<option selected>${esc(c.source)}</option>`)
  $('#source').value = c.source
  $('#enabled').checked = c.enabled
  $('#auto').checked = c.auto
  setVal($('#fps'), c.fps)
  for (const el of $$('[data-t]')) setVal(el, c.tracker[el.dataset.t])
  $('#splitAxis').value = c.tracker.split.axis
  $('#build').textContent = cam.build
    ? `Learning the cards: ${cam.build.done} / ${cam.build.total}…`
    : cam.indexSize ? `Knows ${cam.indexSize} cards.` : ''
  if (appState) {
    $('#p0name').textContent = appState.players[0].name
    $('#p1name').textContent = appState.players[1].name
  }
  const who = (o) => (o === null || o === undefined || !appState ? '' : ` · ${esc(appState.players[o].name)}`)
  const KIND = { shown: 'shown', suggested: 'suggested', unsure: 'not sure', moved: 'moved/turned', info: 'note' }
  $('#log').innerHTML = cam.log.length
    ? cam.log.map((e) => `<div class="ev ${e.type}"><span class="t">${new Date(e.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
        <span><span class="kind">${KIND[e.type] ?? e.type}</span> ${esc(e.text ?? (e.name ?? '').replace(/\s*\([^)]*\)\s*$/, ''))}${who(e.owner)}</span>
        <span class="sc">${e.score !== undefined ? `${e.score.toFixed(2)} / +${e.margin.toFixed(2)}` : ''}</span></div>`).join('')
    : `<div class="hint">Nothing yet. Played cards appear here with how sure it was (score / lead over the next card).</div>`
  draw()
}

function connect() {
  const es = new EventSource('/api/events')
  es.onmessage = (ev) => {
    const msg = JSON.parse(ev.data)
    cam = msg.camera
    appState = msg.state
    render()
    if (!frameLoaded && cam.frameSize) refreshFrame()
  }
}
connect()
