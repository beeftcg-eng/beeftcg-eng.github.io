import { test } from 'node:test'
import assert from 'node:assert/strict'
import { decodePng, encodePng } from '../lib/png.js'
import { FEATURE_LEN, referenceFingerprint } from '../lib/vision/features.js'
import { FingerprintDB } from '../lib/vision/db.js'
import { Tracker, identify, sameName } from '../lib/vision/tracker.js'
import { makeMat, cloneImage, drawCard, cameraize, rng } from '../lib/vision/synth.js'

// Made-up cards that share a card-like layout (art on top, white text box below), so they are
// about as alike as real ones.
function fakeCard(seed) {
  const r = rng(seed)
  const w = 150, h = 210
  const data = new Uint8ClampedArray(w * h * 4)
  const shapes = Array.from({ length: 9 }, () => ({ x: r() * w, y: r() * h * 0.6, rx: 10 + r() * 50, ry: 10 + r() * 40, c: [r() * 255, r() * 255, r() * 255] }))
  const bg = [r() * 255, r() * 255, r() * 255]
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let c = bg
    if (y > h * 0.62) c = (y % 14 < 3 && x > 15 && x < w - 15 && y < h * 0.92) ? [40, 40, 40] : [235, 230, 220]
    else for (const s of shapes) if (((x - s.x) / s.rx) ** 2 + ((y - s.y) / s.ry) ** 2 < 1) c = s.c
    const o = (y * w + x) * 4
    data[o] = c[0]; data[o + 1] = c[1]; data[o + 2] = c[2]; data[o + 3] = 255
  }
  return { width: w, height: h, data }
}

const CARDS = Array.from({ length: 40 }, (_, i) => ({ id: `c${i}`, name: `Card ${i}`, img: fakeCard(i + 100) }))
const db = new FingerprintDB(CARDS.map((c) => c.id), (() => {
  const data = new Float32Array(CARDS.length * FEATURE_LEN)
  CARDS.forEach((c, i) => data.set(referenceFingerprint(c.img), i * FEATURE_LEN))
  return data
})())
const info = (id) => {
  const c = CARDS.find((x) => x.id === id)
  return c && { name: c.name, nameKey: c.name.toLowerCase() }
}

const W = 960, H = 540
const CARD_W = 70
const mat = makeMat(W, H, 3)

/** Runs a little "video": each step is a list of things on the table, for `frames` frames at 3 per second. */
function play(tracker, steps) {
  const events = []
  let t = 0
  let k = 0
  for (const step of steps) {
    for (let f = 0; f < step.frames; f++) {
      const frame = cloneImage(mat)
      for (const it of step.items) drawCard(frame, it.img, { cx: it.cx, cy: it.cy, w: it.w ?? CARD_W, angle: it.angle ?? 0, sleeve: it.sleeve ?? [90, 30, 140] })
      cameraize(frame, { seed: ++k, noise: 5, cast: [1.05, 0.97, 0.92] })
      events.push(...tracker.process(frame, t, (fr, pose) => identify(fr, pose, db, info)).map((e) => ({ ...e, t })))
      t += 1 / 3
    }
  }
  return events
}

const newTracker = () => new Tracker({ cardSize: { w: CARD_W / W, h: CARD_W / 0.716 / H }, split: { axis: 'x', at: 0.5, first: 0 } })
const shows = (events) => events.filter((e) => e.type === 'show')

test('PNG decode reads back what encode wrote', () => {
  const img = fakeCard(1)
  const back = decodePng(encodePng(img))
  assert.equal(back.width, img.width)
  assert.deepEqual(back.data.slice(0, 400), img.data.slice(0, 400))
})

test('a played card is shown once it has stayed put, for the player on that side', () => {
  const tr = newTracker()
  const card = { img: CARDS[7].img, cx: 700, cy: 270 }
  const ev = play(tr, [
    { frames: 4, items: [] },
    { frames: 3, items: [] }, // still nothing
    { frames: 10, items: [card] },
  ])
  const s = shows(ev)
  assert.equal(s.length, 1)
  assert.equal(s[0].cardId, 'c7')
  assert.equal(s[0].owner, 1) // right half
  // It waited for the card to settle for the configured 2 seconds.
  assert.ok(s[0].t >= (7 / 3) + 2 - 0.01, `shown too early at ${s[0].t}`)
})

test('resetting the table mid-game works and starts from what is there now', () => {
  const tr = newTracker()
  const a = { img: CARDS[5].img, cx: 300, cy: 260 }
  play(tr, [{ frames: 4, items: [] }, { frames: 10, items: [a] }])
  tr.reset()
  const ev = play(tr, [{ frames: 4, items: [a] }, { frames: 10, items: [a, { img: CARDS[6].img, cx: 650, cy: 260 }] }])
  assert.deepEqual(shows(ev).map((e) => e.cardId), ['c6'])
})

test('upside-down cards (the far player) are recognised too', () => {
  const tr = newTracker()
  const ev = play(tr, [{ frames: 4, items: [] }, { frames: 10, items: [{ img: CARDS[12].img, cx: 250, cy: 260, angle: Math.PI + 0.08 }] }])
  assert.deepEqual(shows(ev).map((e) => [e.cardId, e.owner]), [['c12', 0]])
})

test('exhausting (turning) a shown card does not show it again; a second copy does', () => {
  const tr = newTracker()
  const a = { img: CARDS[3].img, cx: 300, cy: 260 }
  const turned = { ...a, angle: Math.PI / 2 }
  const copy = { img: CARDS[3].img, cx: 430, cy: 260 }
  const ev = play(tr, [
    { frames: 4, items: [] },
    { frames: 10, items: [a] },
    { frames: 12, items: [turned] },
    { frames: 12, items: [turned, copy] },
  ])
  const s = shows(ev)
  assert.equal(s.length, 2, JSON.stringify(ev.map((e) => [e.type, e.name, e.t.toFixed(1)])))
  assert.ok(s.every((e) => e.cardId === 'c3'))
})

test('a face-down card is not shown as anything', () => {
  const tr = newTracker()
  const back = { width: 150, height: 210, data: new Uint8ClampedArray(150 * 210 * 4).map((_, i) => (i % 4 === 3 ? 255 : i % 4 === 2 ? 160 : 60)) }
  const ev = play(tr, [{ frames: 4, items: [] }, { frames: 12, items: [{ img: back, cx: 500, cy: 300 }] }])
  assert.equal(shows(ev).length, 0)
})

test('nothing is judged while a hand keeps moving over the card', () => {
  const tr = newTracker()
  const card = { img: CARDS[20].img, cx: 600, cy: 300 }
  const hand = (k) => ({ img: { width: 60, height: 60, data: new Uint8ClampedArray(60 * 60 * 4).fill(200) }, cx: 600 + (k % 2) * 30, cy: 250 + (k % 3) * 20, w: 90 })
  const moving = Array.from({ length: 12 }, (_, k) => ({ frames: 1, items: [card, hand(k)] }))
  const ev = play(tr, [{ frames: 4, items: [] }, ...moving, { frames: 10, items: [card] }])
  const s = shows(ev)
  assert.equal(s.length, 1)
  assert.equal(s[0].cardId, 'c20')
  assert.ok(s[0].t > (4 + 12) / 3 + 1.9, `judged while the hand was still moving (${s[0].t})`)
})

test('same card under two names counts as one', () => {
  assert.ok(sameName('rogue assassin', 'akali rogue assassin'))
  assert.ok(!sameName('rogue', 'akali rogue assassin'))
})

test('live loop: OBS snapshots in, card on screen out (against a stand-in OBS)', async () => {
  const { startFakeObs } = await import('./fake-obs.js')
  const { CameraEngine } = await import('../lib/vision/engine.js')
  const os = await import('node:os')
  const fs = await import('node:fs')
  const path = await import('node:path')
  const obs = await startFakeObs({ password: 'pw' })
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'riftcast-test-'))
  const shown = []
  const cards = CARDS.map((c) => ({ id: c.id, name: c.name, imageUrl: 'x' }))
  const players = [{ name: 'A', legendId: null, battlefieldIds: [], main: [], sideboard: [] }, { name: 'B', legendId: null, battlefieldIds: [], main: [], sideboard: [] }]
  const engine = new CameraEngine({
    dataDir: dir,
    getIndex: () => ({ cards, byId: new Map(cards.map((c) => [c.id, c])) }),
    getState: () => ({ players }),
    show: (cardId, owner) => shown.push([cardId, owner]),
    onChange: () => {},
  })
  engine.db = db
  const frame = (items) => {
    const f = cloneImage(mat)
    for (const it of items) drawCard(f, it.img, { cx: it.cx, cy: it.cy, w: CARD_W })
    return encodePng(cameraize(f, { seed: Math.floor(Math.random() * 1e6), noise: 4 }))
  }
  obs.png = frame([])
  try {
    await engine.updateConfig({
      obsUrl: `ws://127.0.0.1:${obs.port}`, obsPassword: 'pw', source: 'Table Cam', enabled: true, auto: true, fps: 8,
      tracker: { cardSize: { w: CARD_W / W, h: CARD_W / 0.716 / H }, stableSec: 1 },
    })
    assert.deepEqual(await engine.listSources(), ['Table Cam', 'Face Cam'])
    await new Promise((r) => setTimeout(r, 1500))
    assert.equal(engine.status.phase, 'watching', engine.status.message)
    obs.png = frame([{ img: CARDS[9].img, cx: 250, cy: 280 }])
    for (let i = 0; i < 40 && !shown.length; i++) await new Promise((r) => setTimeout(r, 150))
    assert.deepEqual(shown, [['c9', 0]])
    assert.equal(engine.log[0].type, 'shown')
  } finally {
    engine.stop()
    engine.obs?.close()
    await obs.close()
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

test('a wrong OBS password is reported clearly', async () => {
  const { startFakeObs } = await import('./fake-obs.js')
  const { ObsClient } = await import('../lib/obs.js')
  const obs = await startFakeObs({ password: 'right' })
  const client = new ObsClient({ url: `ws://127.0.0.1:${obs.port}`, password: 'wrong' })
  try {
    await assert.rejects(client.sourceNames(), /password|closed/)
  } finally {
    client.close()
    await obs.close()
  }
})
