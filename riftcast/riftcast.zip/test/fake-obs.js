// A tiny stand-in for OBS's websocket server (protocol v5), for tests: password handshake,
// GetInputList and GetSourceScreenshot (serving whatever PNG the test sets).
import http from 'node:http'
import crypto from 'node:crypto'

const sha256b64 = (s) => crypto.createHash('sha256').update(s).digest('base64')

export function startFakeObs({ password = 'secret', sources = ['Table Cam', 'Face Cam'] } = {}) {
  const salt = 'saltsalt', challenge = 'challenge123'
  const expected = sha256b64(sha256b64(password + salt) + challenge)
  const fake = { png: null, requests: [], server: null, port: 0 }

  const server = http.createServer()
  server.on('upgrade', (req, socket) => {
    const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')
    socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\nSec-WebSocket-Protocol: obswebsocket.json\r\n\r\n`.replace('Sec-WebSocket-Protocol: obswebsocket.json\r\n', req.headers['sec-websocket-protocol'] ? 'Sec-WebSocket-Protocol: obswebsocket.json\r\n' : ''))
    const send = (obj) => {
      const payload = Buffer.from(JSON.stringify(obj))
      let header
      if (payload.length < 126) header = Buffer.from([0x81, payload.length])
      else if (payload.length < 65536) {
        header = Buffer.alloc(4); header[0] = 0x81; header[1] = 126; header.writeUInt16BE(payload.length, 2)
      } else {
        header = Buffer.alloc(10); header[0] = 0x81; header[1] = 127; header.writeBigUInt64BE(BigInt(payload.length), 2)
      }
      socket.write(Buffer.concat([header, payload]))
    }
    let buf = Buffer.alloc(0)
    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk])
      while (buf.length >= 2) {
        let len = buf[1] & 127, off = 2
        if (len === 126) { len = buf.readUInt16BE(2); off = 4 } else if (len === 127) { len = Number(buf.readBigUInt64BE(2)); off = 10 }
        if (buf.length < off + 4 + len) return
        const mask = buf.subarray(off, off + 4)
        const data = Buffer.from(buf.subarray(off + 4, off + 4 + len)).map((b, i) => b ^ mask[i % 4])
        const opcode = buf[0] & 15
        buf = buf.subarray(off + 4 + len)
        if (opcode === 8) return socket.end()
        if (opcode !== 1) continue
        const msg = JSON.parse(data.toString())
        if (msg.op === 1) {
          if (msg.d.authentication !== expected) return socket.end(Buffer.from([0x88, 2, 0x0f, 0xa9])) // close 4009
          send({ op: 2, d: { negotiatedRpcVersion: 1 } })
        } else if (msg.op === 6) {
          fake.requests.push(msg.d.requestType)
          const reply = (responseData, ok = true, comment) => send({ op: 7, d: { requestType: msg.d.requestType, requestId: msg.d.requestId, requestStatus: { result: ok, code: ok ? 100 : 600, comment }, responseData } })
          if (msg.d.requestType === 'GetInputList') reply({ inputs: sources.map((inputName) => ({ inputName, inputKind: 'v4l2_input' })) })
          else if (msg.d.requestType === 'GetSourceScreenshot') {
            if (!sources.includes(msg.d.requestData.sourceName)) reply(undefined, false, 'No source was found by the name')
            else reply({ imageData: `data:image/png;base64,${fake.png.toString('base64')}` })
          } else reply(undefined, false, 'Unknown request')
        }
      }
    })
    socket.on('error', () => {})
    send({ op: 0, d: { obsWebSocketVersion: '5.5.0', rpcVersion: 1, authentication: { challenge, salt } } })
  })
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => {
    fake.server = server
    fake.port = server.address().port
    fake.close = () => new Promise((r) => { server.closeAllConnections?.(); server.close(r) })
    resolve(fake)
  }))
}
