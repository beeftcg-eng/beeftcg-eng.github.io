import test from 'node:test'
import assert from 'node:assert/strict'
import { PairingsLink, parseBracketRef, records, recordText, roundLabel, findLegend, currentTables } from '../lib/pairings.js'
import { initialState, reduce } from '../lib/state.js'
import { CardIndex, normalizeCard } from '../lib/cards.js'

const ID = '0f8c2a6e-1b2c-4d5e-8f90-123456789abc'
const P = (n) => `00000000-0000-4000-8000-00000000000${n}`
const bracket = (over = {}) => ({
  id: ID, name: 'Friday Riftbound', version: 3, status: 'swiss', settings: { rounds: 4 }, store: { name: 'Beef Games' },
  players: [
    { id: P(1), name: 'Hellsky', deck: 'Jinx' },
    { id: P(2), name: 'Joey', deck: 'Ahri - Nine-Tailed Fox' },
    { id: P(3), name: 'Dana', deck: 'Mystery Deck' },
    { id: P(4), name: 'Sam', deck: '' },
    { id: P(5), name: 'Lee', deck: '' },
  ],
  matches: [
    { id: 'm1', stage: 'swiss', round: 1, table: 1, p1: P(1), p2: P(3), result: 'p1', status: 'confirmed' },
    { id: 'm2', stage: 'swiss', round: 1, table: 2, p1: P(2), p2: P(4), result: 'draw', status: 'confirmed' },
    { id: 'm3', stage: 'swiss', round: 1, table: null, p1: P(5), p2: null, result: null, status: 'confirmed' },
    { id: 'm4', stage: 'swiss', round: 2, table: 2, p1: P(3), p2: P(5), result: null, status: 'pending' },
    { id: 'm5', stage: 'swiss', round: 2, table: 1, p1: P(1), p2: P(2), result: 'p2', status: 'reported', p1Games: 1, p2Games: 2 },
  ],
  ...over,
})

const index = new CardIndex([
  { id: 'jinx1', name: 'Jinx - Loose Cannon', classification: { type: 'Legend' } },
  { id: 'ahri1', name: 'Ahri - Nine-Tailed Fox', classification: { type: 'Legend' } },
  { id: 'kai1', name: "Kai'Sa - Daughter of the Void", classification: { type: 'Legend' } },
  { id: 'kai2', name: "Kai'Sa - Survivor", classification: { type: 'Legend' } },
  { id: 'unit', name: 'Jinx Fan', classification: { type: 'Unit' } },
].map(normalizeCard))

test('bracket links and bare ids are understood', () => {
  assert.equal(parseBracketRef(`https://pairings-coral.vercel.app/?bracket=${ID.toUpperCase()}&p=abc`), ID)
  assert.equal(parseBracketRef(ID), ID)
  assert.equal(parseBracketRef('https://example.com/nothing'), null)
})

test('records count byes as wins and leave out the match itself', () => {
  const r = records(bracket())
  assert.equal(recordText(r.get(P(1))), '1-1')
  assert.equal(recordText(r.get(P(2))), '1-0-1')
  assert.equal(recordText(r.get(P(5))), '1-0')
  const t = currentTables(bracket())
  assert.equal(t.round, 2)
  assert.equal(t.label, 'Round 2 of 4')
  assert.deepEqual(t.tables.map((x) => x.table), [1, 2])
  assert.equal(t.tables[0].p1.record, '1-0') // Hellsky coming into round 2, before losing it
  assert.equal(t.tables[0].p2.record, '0-0-1')
})

test('elimination rounds are named by size', () => {
  const b = bracket({ matches: [
    { id: 'e1', stage: 'elim', round: 1, p1: P(1), p2: P(2) }, { id: 'e2', stage: 'elim', round: 1, p1: P(3), p2: P(4) },
    { id: 'e3', stage: 'elim', round: 2, p1: P(1), p2: P(3) },
  ] })
  assert.equal(roundLabel(b, 'elim', 1), 'Semifinals')
  assert.equal(roundLabel(b, 'elim', 2), 'Final')
  assert.equal(currentTables(b).label, 'Final')
})

test('legends: full names, champion only when unambiguous', () => {
  assert.equal(findLegend(index, 'Jinx')?.id, 'jinx1')
  assert.equal(findLegend(index, 'Ahri - Nine-Tailed Fox')?.id, 'ahri1')
  assert.equal(findLegend(index, "Kai'Sa"), null) // two Kai'Sa legends: don't guess
  assert.equal(findLegend(index, 'Mystery Deck'), null)
  assert.equal(findLegend(index, ''), null)
})

function setup(b = bracket()) {
  let state = initialState()
  const calls = []
  const fetchImpl = async (url, opts) => {
    const name = url.split('/rpc/')[1]
    const args = JSON.parse(opts.body)
    calls.push([name, args, opts.headers.apikey])
    const found = args.p_bracket === ID
    const body = name === 'get_bracket' ? (found ? structuredClone(b) : null) : found ? b.version : null
    return { ok: true, json: async () => body }
  }
  const link = new PairingsLink({
    getState: () => state, getIndex: () => index, onChange: () => {}, fetch: fetchImpl, url: 'https://x.supabase.co', key: 'anon',
    apply: (a) => (state = reduce(state, a, { now: Date.now() })),
  })
  return { link, calls, get state() { return state } }
}

test('linking, featuring a table, and unlinking', async () => {
  const t = setup()
  await assert.rejects(t.link.link('not a link'), /isn’t a Pairings bracket link/)
  await assert.rejects(t.link.link('11111111-2222-4333-8444-555555555555'), /No bracket/)
  await t.link.link(`https://pairings-coral.vercel.app/?bracket=${ID}`)
  await new Promise((r) => setTimeout(r, 10))
  assert.equal(t.state.pairingsBracket, ID)
  assert.equal(t.calls[0][2], 'anon')
  const st = t.link.publicStatus()
  assert.equal(st.bracket.tables.length, 2)

  t.state.players[0].points = 5
  t.link.feature('m5')
  const s = t.state
  assert.deepEqual(s.players.map((p) => [p.name, p.record, p.legendId, p.points]), [['Hellsky', '1-0', 'jinx1', 0], ['Joey', '0-0-1', 'ahri1', 0]])
  assert.equal(s.event.name, 'Friday Riftbound')
  assert.equal(s.event.location, 'Beef Games')
  assert.equal(s.event.stage, 'Table 1')
  assert.equal(s.round.current, 2)
  assert.equal(s.round.total, 4)
  assert.equal(s.pairingsFeatured, 'm5')
  assert.throws(() => t.link.feature('m3'), /isn’t in the current round/)

  t.link.unlink()
  assert.equal(t.state.pairingsBracket, null)
  t.link.close()
})

test('polling only refetches the bracket when its version changes', async () => {
  const b = bracket()
  const t = setup(b)
  await t.link.link(ID)
  await new Promise((r) => setTimeout(r, 10))
  const gets = () => t.calls.filter(([n]) => n === 'get_bracket').length
  const before = gets()
  await t.link.poll()
  assert.equal(gets(), before)
  b.version = 4
  await t.link.poll()
  assert.equal(gets(), before + 1)
  t.link.close()
})
