import test from 'node:test'
import assert from 'node:assert/strict'
import { PhoneLinks, newCode, phoneView } from '../lib/phones.js'
import { initialState, reduce } from '../lib/state.js'

// A relay stand-in: records what Riftcast sends and lets the test play the phone.
function fakeRelay() {
  const chans = new Map()
  return {
    chans,
    channel(name, onMessage, onStatus) {
      const ch = { name, sent: [], left: false, onMessage, send: (ev, p) => (ch.sent.push([ev, p]), true), leave: () => (ch.left = true) }
      chans.set(name, ch)
      queueMicrotask(() => onStatus('joined'))
      return ch
    },
    close() {},
  }
}

function setup() {
  const relay = fakeRelay()
  let state = initialState()
  state.players[0].name = 'Hellsky'
  state.players[1].name = 'Joey'
  const links = new PhoneLinks({
    relay,
    getState: () => state,
    apply: (a) => { state = reduce(state, a, { now: Date.now() }); links.sync(); links.publish() },
    onChange: () => {},
  })
  const apply = (a) => links.deps.apply(a)
  return { relay, links, apply, get state() { return state } }
}

const tick = () => new Promise((r) => setTimeout(r, 0))
const lastState = (ch) => ch.sent.filter(([e]) => e === 'state').at(-1)?.[1]

test('codes use the easy-to-read alphabet', () => {
  for (let i = 0; i < 200; i++) assert.match(newCode(), /^[A-HJ-NP-Z2-9]{6}$/)
})

test('a linked app sets only its own player\'s points and gets its scoreboard back', async () => {
  const t = setup()
  t.apply({ type: 'phoneCodes', codes: ['AAAAAA', 'BBBBBB'] })
  await tick()
  const a = t.relay.chans.get('riftcast-AAAAAA')
  assert.equal(lastState(a).me.name, 'Hellsky')
  a.onMessage('points', { points: 4 })
  assert.equal(t.state.players[0].points, 4)
  assert.equal(t.state.players[1].points, 0)
  assert.deepEqual(lastState(a).me.points, 4)
  assert.equal(lastState(t.relay.chans.get('riftcast-BBBBBB')).them.points, 4)
  assert.deepEqual(t.links.status().linked, [true, false])
  a.onMessage('points', { points: 5, kind: 'conquer' })
  assert.equal(t.state.pointLog.at(-1).reason, 'player app: conquer')
  a.onMessage('points', { points: 4, kind: '<script>' })
  assert.equal(t.state.pointLog.at(-1).reason, 'player app')
  a.onMessage('points', { points: 'lots' })
  a.onMessage('points', { points: 500 })
  assert.equal(t.state.players[0].points, 4)
})

test('swap sides keeps each app linked to its own player', async () => {
  const t = setup()
  t.apply({ type: 'phoneCodes', codes: ['AAAAAA', 'BBBBBB'] })
  await tick()
  const a = t.relay.chans.get('riftcast-AAAAAA')
  t.apply({ type: 'swapSides' })
  assert.equal(a.left, false)
  assert.ok(!a.sent.some(([e]) => e === 'expired'))
  assert.equal(lastState(a).me.name, 'Hellsky')
  a.onMessage('points', { points: 3 })
  assert.equal(t.state.players[1].name, 'Hellsky')
  assert.equal(t.state.players[1].points, 3)
  assert.equal(t.state.players[0].points, 0)
})

test('new codes tell the old apps the match is over', async () => {
  const t = setup()
  t.apply({ type: 'phoneCodes', codes: ['AAAAAA', 'BBBBBB'] })
  await tick()
  const a = t.relay.chans.get('riftcast-AAAAAA')
  t.apply({ type: 'phoneCodes', codes: ['CCCCCC', 'DDDDDD'] })
  assert.ok(a.sent.some(([e]) => e === 'expired'))
  assert.equal(a.left, true)
  a.onMessage('points', { points: 7 })
  assert.equal(t.state.players[0].points, 0)
})

test('the app view holds nothing private', () => {
  const s = initialState()
  const v = phoneView(s, 0)
  assert.deepEqual(Object.keys(v).sort(), ['event', 'me', 'round', 'them', 'timer', 'winPoints'])
  assert.ok(!JSON.stringify(v).includes('deck'))
})

test('one table phone sets both players\' points', async () => {
  const t = setup()
  t.apply({ type: 'phoneCodes', codes: ['AAAAAA', 'BBBBBB'], table: 'TTTTTT' })
  await tick()
  const tp = t.relay.chans.get('riftcast-TTTTTT')
  const view = lastState(tp)
  assert.equal(view.both, true)
  assert.equal(view.me.name, 'Hellsky')
  assert.equal(view.them.name, 'Joey')
  tp.onMessage('points', { points: 3, kind: 'hold' })
  tp.onMessage('points', { points: 5, kind: 'conquer', who: 'them' })
  assert.equal(t.state.players[0].points, 3)
  assert.equal(t.state.players[1].points, 5)
  assert.equal(t.state.pointLog.at(-1).reason, 'table phone: conquer')
  assert.equal(lastState(tp).them.points, 5)
  assert.equal(t.links.status().tableLinked, true)
  assert.deepEqual(t.links.status().linked, [false, false])
  // Players' own codes still can't touch the opponent.
  t.relay.chans.get('riftcast-AAAAAA').onMessage('points', { points: 1, who: 'them' })
  assert.equal(t.state.players[0].points, 1)
  assert.equal(t.state.players[1].points, 5)
  assert.ok(!('both' in lastState(t.relay.chans.get('riftcast-AAAAAA'))))
})

test('the table phone follows the players when sides are swapped', async () => {
  const t = setup()
  t.apply({ type: 'phoneCodes', codes: ['AAAAAA', 'BBBBBB'], table: 'TTTTTT' })
  await tick()
  const tp = t.relay.chans.get('riftcast-TTTTTT')
  t.apply({ type: 'swapSides' })
  assert.equal(tp.left, false)
  assert.equal(lastState(tp).me.name, 'Hellsky')
  tp.onMessage('points', { points: 2 })
  tp.onMessage('points', { points: 6, who: 'them' })
  assert.equal(t.state.players[1].name, 'Hellsky')
  assert.equal(t.state.players[1].points, 2)
  assert.equal(t.state.players[0].points, 6)
})

test('a new match retires the table code too', async () => {
  const t = setup()
  t.apply({ type: 'phoneCodes', codes: ['AAAAAA', 'BBBBBB'], table: 'TTTTTT' })
  await tick()
  const tp = t.relay.chans.get('riftcast-TTTTTT')
  t.apply({ type: 'newMatch' })
  assert.ok(tp.sent.some(([e]) => e === 'expired'))
  assert.equal(tp.left, true)
  assert.equal(t.state.tableCode, null)
})
