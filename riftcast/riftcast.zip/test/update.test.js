import test from 'node:test'
import assert from 'node:assert/strict'
import crypto from 'node:crypto'
import fs from 'node:fs'
import http from 'node:http'
import os from 'node:os'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { compareVersions, readZip, safeTarget, Updater } from '../lib/update.js'

const ROOT = path.resolve(import.meta.dirname, '..')
const gitZip = () => execFileSync('git', ['archive', '--format=zip', 'HEAD'], { cwd: ROOT, maxBuffer: 64 << 20 })

test('versions compare by number, not as text', () => {
  assert.equal(compareVersions('0.10.0', '0.9.9'), 1)
  assert.equal(compareVersions('0.5.2', '0.5.2'), 0)
  assert.equal(compareVersions('0.5', '0.5.1'), -1)
})

test('reads the zips git archive makes', () => {
  const files = readZip(gitZip())
  const server = files.find((f) => f.name === 'server.js')
  assert.ok(server)
  assert.equal(server.data.toString(), execFileSync('git', ['show', 'HEAD:server.js'], { cwd: ROOT }).toString())
})

test('an update never writes into data/ or outside the folder', () => {
  const root = path.resolve('/x/riftcast')
  assert.equal(safeTarget(root, 'lib/cards.js'), path.join(root, 'lib/cards.js'))
  for (const bad of ['data/state.json', 'data', '../evil.js', '/etc/passwd', 'C:/x.js', 'lib/../../x', '']) assert.equal(safeTarget(root, bad), null, bad)
})

async function serve(files) {
  const srv = http.createServer((req, res) => {
    const f = files[new URL(req.url, 'http://x').pathname]
    if (!f) return res.writeHead(404).end()
    res.writeHead(200).end(f)
  })
  await new Promise((r) => srv.listen(0, '127.0.0.1', r))
  return { srv, url: `http://127.0.0.1:${srv.address().port}` }
}

test('installs a newer release over the folder, leaving data/ alone', async () => {
  const zip = gitZip()
  const sha = crypto.createHash('sha256').update(zip).digest('hex')
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'riftcast-update-'))
  fs.mkdirSync(path.join(root, 'data'))
  fs.writeFileSync(path.join(root, 'data/state.json'), 'keep me')
  fs.writeFileSync(path.join(root, 'server.js'), 'old')
  const { srv, url } = await serve({
    '/latest.json': JSON.stringify({ version: '99.0.0', notes: 'New stuff', zip: 'r.zip', sha256: sha }),
    '/r.zip': zip,
  })
  try {
    const u = new Updater({ root, version: '0.1.0', url: `${url}/latest.json` })
    await u.check()
    assert.equal(u.status().available, true)
    assert.equal(u.status().latest.notes, 'New stuff')
    const n = await u.install()
    assert.ok(n > 10)
    assert.notEqual(fs.readFileSync(path.join(root, 'server.js'), 'utf8'), 'old')
    assert.equal(fs.readFileSync(path.join(root, 'data/state.json'), 'utf8'), 'keep me')
    assert.equal(u.status().state, 'installed')
  } finally {
    srv.close()
    fs.rmSync(root, { recursive: true, force: true })
  }
})

test('a damaged download changes nothing', async () => {
  const zip = gitZip()
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'riftcast-update-'))
  fs.writeFileSync(path.join(root, 'server.js'), 'old')
  const { srv, url } = await serve({
    '/latest.json': JSON.stringify({ version: '99.0.0', zip: 'r.zip', sha256: '0'.repeat(64) }),
    '/r.zip': zip,
  })
  try {
    const u = new Updater({ root, version: '0.1.0', url: `${url}/latest.json` })
    await u.check()
    await assert.rejects(u.install(), /checksum/)
    assert.equal(fs.readFileSync(path.join(root, 'server.js'), 'utf8'), 'old')
    assert.match(u.status().error, /checksum/)
  } finally {
    srv.close()
    fs.rmSync(root, { recursive: true, force: true })
  }
})

test('no newer version: nothing to install', async () => {
  const { srv, url } = await serve({ '/latest.json': JSON.stringify({ version: '0.1.0', zip: 'r.zip', sha256: 'a'.repeat(64) }) })
  try {
    const u = new Updater({ root: '/nowhere', version: '0.1.0', url: `${url}/latest.json` })
    await u.check()
    assert.equal(u.status().available, false)
    await assert.rejects(u.install(), /No newer version/)
  } finally {
    srv.close()
  }
})
