import { test } from 'node:test'
import assert from 'node:assert/strict'
import { CardIndex, parseDecklist } from '../lib/cards.js'
import { initialState, reduce } from '../lib/state.js'
import { RiftAtlasLink } from '../lib/riftatlas.js'

const card = (id, name, category, code) => ({ id, name, category, code, supertype: null, domains: [], imageUrl: 'x', orientation: 'portrait', special: false })
const index = new CardIndex([
  card('L1', 'Teemo - Swift Scout', 'Legend', 'ogn-001-298'),
  card('L2', 'Leona - Radiant Dawn', 'Legend', 'ogn-002-298'),
  card('U1', 'Evershade Stalker', 'Unit', 'unl-123-219'),
  card('U1a', 'Evershade Stalker (Alternate Art)', 'Unit', 'unl-123a-219'),
  card('S1', 'Isolate', 'Spell', 'unl-124-219'),
])

function setup() {
  let state = initialState()
  const link = new RiftAtlasLink({
    getIndex: () => index,
    getState: () => state,
    apply: (a) => (state = reduce(state, a, { index, parseDecklist, now: 1 })),
  })
  return { link, get: () => state }
}

test('takes over player names and legends from the Rift Atlas game', () => {
  const { link, get } = setup()
  link.handle({ type: 'players', players: { self: 'Beeftcg', opponent: 'Joey' }, legends: { self: 'Teemo, Swift Scout', opponent: 'Leona, Radiant Dawn' } })
  assert.deepEqual(get().players.map((p) => [p.name, p.legendId]), [['Beeftcg', 'L1'], ['Joey', 'L2']])
})

test('a played card goes on screen for the player who played it, matched by name from either seat', () => {
  const { link, get } = setup()
  link.handle({ type: 'players', players: { self: 'Beeftcg', opponent: 'Joey' } })
  // Viewed from Joey's seat: Joey is "self" now, but stays the right player.
  link.handle({ type: 'played', id: 'a', name: 'Isolate', ownerRole: 'self', ownerName: 'Joey' })
  assert.deepEqual([get().spotlight.cardId, get().spotlight.owner, get().spotlight.source], ['S1', 1, 'riftatlas'])
})

test('the exact printing is shown when Rift Atlas names it', () => {
  const { link, get } = setup()
  link.handle({ type: 'played', id: 'b', name: 'Evershade Stalker', printing: 'UNL-123a', ownerRole: 'self', ownerName: 'X' })
  assert.equal(get().spotlight.cardId, 'U1a')
})

test('the same log entry is never shown twice', () => {
  const { link, get } = setup()
  link.handle({ type: 'played', id: 'c', name: 'Isolate', ownerRole: 'self' })
  const seq = get().spotlight.seq
  assert.equal(link.handle({ type: 'played', id: 'c', name: 'Isolate', ownerRole: 'self' }).duplicate, true)
  assert.equal(get().spotlight.seq, seq)
})

test('points follow both score tracks', () => {
  const { link, get } = setup()
  link.handle({ type: 'players', players: { self: 'Beeftcg', opponent: 'Joey' } })
  link.handle({ type: 'score', self: 3, opponent: 5, players: { self: 'Beeftcg', opponent: 'Joey' } })
  assert.deepEqual(get().players.map((p) => p.points), [3, 5])
})

test('phone codes follow players when sides swap and end with the match', () => {
  let s = initialState()
  const ctx = { index, parseDecklist, now: 1 }
  s = reduce(s, { type: 'phoneCodes', codes: ['AAAA', 'BBBB'] }, ctx)
  s = reduce(s, { type: 'swapSides' }, ctx)
  assert.deepEqual(s.phoneCodes, ['BBBB', 'AAAA'])
  s = reduce(s, { type: 'newMatch' }, ctx)
  assert.deepEqual(s.phoneCodes, [null, null])
})
