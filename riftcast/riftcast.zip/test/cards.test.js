import { test } from 'node:test'
import assert from 'node:assert/strict'
import { CardIndex, nameKey, parseDecklist } from '../lib/cards.js'
import { initialState, reduce } from '../lib/state.js'

const card = (id, name, category, extra = {}) => ({ id, name, category, supertype: null, domains: [], cost: 1, imageUrl: 'x', orientation: 'portrait', special: /\(/.test(name), ...extra })
const cards = [
  card('L1', 'Teemo - Swift Scout', 'Legend'),
  card('L1s', 'Teemo - Swift Scout (Signature)', 'Legend'),
  card('U1a', 'Teemo - Scout (Alternate Art)', 'Unit', { supertype: 'Champion' }),
  card('U1', 'Teemo - Scout', 'Unit', { supertype: 'Champion' }),
  card('U2', 'Bewitching Spirit', 'Unit'),
  card('S1', 'Death from Below', 'Spell'),
  card('S2', "Kha'Zix - Mutating Horror", 'Unit'),
  card('B1', 'Star Spring', 'Battlefield', { orientation: 'landscape' }),
  card('B2', 'Black Flame Altar', 'Battlefield', { orientation: 'landscape' }),
  card('B3', 'Trapping Grounds', 'Battlefield', { orientation: 'landscape' }),
  card('R1', 'Chaos Rune', 'Rune'),
]
const index = new CardIndex(cards)

test('nameKey ignores separators, case and printing suffixes', () => {
  assert.equal(nameKey('Teemo, Swift Scout'), nameKey('Teemo - Swift Scout (Signature)'))
  assert.equal(nameKey('Kha’Zix, Mutating Horror'), nameKey("Kha'Zix - Mutating Horror"))
})

test('a Piltover Archive style decklist resolves to regular printings', () => {
  const text = `Legend:
1 Teemo, Swift Scout

Champion:
1 Teemo, Scout

MainDeck:
3 Bewitching Spirit
2x Death from Below
3 Kha'Zix, Mutating Horror
1 Not A Real Card

Battlefields:
1 Star Spring
1 Black Flame Altar
1 Trapping Grounds

Runes:
6 Chaos Rune
6 Order Rune

Sideboard:
2 Death from Below`
  const deck = parseDecklist(text, index)
  assert.equal(deck.legendId, 'L1')
  assert.deepEqual(deck.battlefieldIds, ['B1', 'B2', 'B3'])
  assert.deepEqual(deck.main, [
    { cardId: 'U1', count: 1 },
    { cardId: 'U2', count: 3 },
    { cardId: 'S1', count: 2 },
    { cardId: 'S2', count: 3 },
  ])
  assert.deepEqual(deck.sideboard, [{ cardId: 'S1', count: 2 }])
  assert.deepEqual(deck.unknown, ['1 Not A Real Card'])
})

test('a list with no headings is placed by card type', () => {
  const deck = parseDecklist('Teemo, Swift Scout\n3 Bewitching Spirit\nStar Spring', index)
  assert.equal(deck.legendId, 'L1')
  assert.deepEqual(deck.battlefieldIds, ['B1'])
  assert.deepEqual(deck.main, [{ cardId: 'U2', count: 3 }])
})

test('scoring, game reset and spotlight', () => {
  const ctx = { index, parseDecklist, now: 1000 }
  let s = initialState()
  s = reduce(s, { type: 'points', player: 1, delta: 1 }, ctx)
  s = reduce(s, { type: 'points', player: 1, delta: 1 }, ctx)
  s = reduce(s, { type: 'points', player: 0, delta: -1 }, ctx)
  assert.equal(s.players[1].points, 2)
  assert.equal(s.players[0].points, 0)
  s = reduce(s, { type: 'show', cardId: 'S1', player: 1 }, ctx)
  assert.deepEqual([s.spotlight.cardId, s.spotlight.owner], ['S1', 1])
  s = reduce(s, { type: 'swapSides' }, ctx)
  assert.equal(s.spotlight.owner, 0)
  assert.equal(s.players[0].points, 2)
  s = reduce(s, { type: 'newGame' }, ctx)
  assert.equal(s.players[0].points, 0)
  assert.equal(s.spotlight.cardId, null)
  assert.throws(() => reduce(s, { type: 'show', cardId: 'nope' }, ctx))
})

test('timer runs, pauses and adjusts', () => {
  let s = initialState()
  s = reduce(s, { type: 'timerReset', minutes: 50 }, { now: 0 })
  s = reduce(s, { type: 'timerStart' }, { now: 0 })
  s = reduce(s, { type: 'timerPause' }, { now: 60_000 })
  assert.equal(s.timer.remainingMs, 49 * 60_000)
  s = reduce(s, { type: 'timerAdjust', seconds: 60 }, { now: 60_000 })
  assert.equal(s.timer.remainingMs, 50 * 60_000)
})

test('official gallery cards get riftcodex-style names and fill in only missing sets', async () => {
  const { normalizeGalleryCard, mergeCardSources } = await import('../lib/cards.js')
  const img = { url: 'https://cmsassets.rgpub.io/x.png', accessibilityText: 'Riftbound Spell: Hush. [Reaction]' }
  const g = (id, name, type, extra = {}) => ({ id, name, set: { value: { id: id.split('-')[0].toUpperCase() } }, cardType: { type: type ? [{ id: type.toLowerCase(), label: type }] : [] }, domain: { values: [{ label: 'Calm' }] }, cardImage: img, orientation: 'portrait', energy: { value: { id: 2 } }, ...extra })
  const hush = normalizeGalleryCard(g('rad-041-167', 'Hush', null))
  assert.deepEqual([hush.id, hush.name, hush.category, hush.set, hush.cost, hush.special], ['rb-rad-041-167', 'Hush', 'Spell', 'RAD', 2, false])
  const legend = normalizeGalleryCard(g('rad-153-167', "Agony's Embrace", 'Legend', { tags: { tags: ['Evelynn'] } }))
  assert.equal(legend.name, "Evelynn - Agony's Embrace")
  assert.equal(normalizeGalleryCard(g('rad-141-167', 'Hexplosives Expert', 'Legend', { tags: { tags: ['Yordle', 'Ziggs'] } })).name, 'Ziggs - Hexplosives Expert')
  assert.equal(normalizeGalleryCard(g('rad-175-167', "Agony's Embrace", 'Legend', { tags: { tags: ['Evelynn'] } })).name, "Evelynn - Agony's Embrace (Overnumbered)")
  const champ = normalizeGalleryCard(g('rad-038-167', 'Ahri', 'Unit', { subtitle: 'Confident', tags: { tags: ['Ahri'] } }))
  assert.deepEqual([champ.name, champ.supertype], ['Ahri - Confident', 'Champion'])
  const alt = normalizeGalleryCard(g('rad-038a-167', 'Ahri', 'Unit', { subtitle: 'Confident' }))
  assert.deepEqual([alt.name, alt.special], ['Ahri - Confident (Alternate Art)', true])
  assert.equal(normalizeGalleryCard(g('rad-sp1-005', 'Ahri', 'Unit', { subtitle: 'Confident' })).special, true)

  const merged = mergeCardSources([{ id: 'x', name: 'Old', set: 'OGN' }], [normalizeGalleryCard(g('ogn-001-298', 'Old', 'Unit')), hush, legend, champ, alt])
  assert.deepEqual(merged.map((c) => c.id), ['x', 'rb-rad-041-167', 'rb-rad-153-167', 'rb-rad-038-167', 'rb-rad-038a-167'])
  const idx = new CardIndex(merged)
  assert.equal(idx.resolve('Ahri, Confident').id, 'rb-rad-038-167')
  assert.equal(idx.resolve("Agony's Embrace", 'legend').id, 'rb-rad-153-167')
})
