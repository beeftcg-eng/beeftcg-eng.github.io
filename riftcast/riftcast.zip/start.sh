#!/bin/sh
# Start Riftcast (Linux / macOS). Needs Node.js 22 or newer.
cd "$(dirname "$0")" && exec node launcher.js
