# Riftcast

A tournament stream overlay for Riftbound. It runs on the streaming PC next to OBS and gives you:

- **Card spotlight. No decklists needed.** Type part of any Riftbound card's name and press Enter. It pops up big over the table for a few seconds, then stays in the side panel until the next card replaces it.
- **Decklists are optional.** If you paste them, those cards rank first in search, show up as click-to-show tiles, and are tagged with the right player automatically.
- Player names, pronouns, record, Legend art, battlefield this game, game wins, and **points (0–8)**.
- Event name, round "3 of 7", and a **round timer**.
- Transparent frames for the table camera and both player cameras.

New to it? Read `START HERE.txt` first.

Card data and images come from riftcodex, the same source the deckbuilder uses. A brand-new set that riftcodex hasn't added yet (Radiance, as of November 2026) is filled in from Riot's official card gallery, and drops back to riftcodex once it's there. They're cached in `data/`, so once a deck is loaded the stream doesn't depend on the venue's internet to show cards.

## Running it on the stream PC

1. Install **Node.js 22 or newer** from https://nodejs.org (the LTS version).
2. Copy this whole `riftcast` folder to the stream PC.
3. Start it:
   - Windows: double-click `start.bat` (it opens the control panel for you)
   - Linux/macOS: run `./start.sh`
4. The first start downloads the card list, which takes a few seconds. Leave the window open while streaming.

## OBS setup (once)

1. **Overlay:** add a *Browser Source* with URL `http://localhost:7420/overlay`, width **1920**, height **1080**. Put it at the **top** of the scene.
2. **Table camera:** put it under the overlay so it fills the centre gap, x 440 to 1480 (1040 × 1080).
3. **Player cameras (optional):** put them under the overlay in the two 16:9 frames. Left frame is about x 16, y 287, 405 × 228. Right frame is about x 1499, y 287, 405 × 228. You can turn the frames off in ⚙ Settings.
4. **Control panel:** either open `http://localhost:7420/control` in a normal browser, or dock it inside OBS with *Docks → Custom Browser Docks…*, name it "Riftcast" and use the same URL.
5. **Break screen (optional):** make a "Break" scene with a *Browser Source* at `http://localhost:7420/break`, 1920 × 1080. Switch to it between matches. It shows the event, round clock, a message (set it in ⚙ Settings, default "We'll be right back"), the match that's up next with both legends, and the round's tables when a Pairings bracket is linked. Large rounds show as many tables as fit, then "+N more tables".

Riftcast only answers this PC by default. To run the control panel from a laptop or tablet on the same network, start it with `HOST=0.0.0.0` set (on Windows: `set HOST=0.0.0.0` then `node server.js`), then open `http://<stream-pc-ip>:7420/control`. Only do this on a network you trust: anyone on it could change the overlay.

## During a match

| Do this | How |
|---|---|
| Show a card | Press **/**, type part of the name, press **Enter**. Word order and punctuation don't matter ("khazix", "scout teemo"). ↑/↓ picks another result, or click any result |
| Who played it | **Tab** in the search box switches *Played by* between left player, right player and nobody. Cards from a loaded decklist use that player automatically |
| Show a card again | With the search box empty, the *Recently shown* row is there to click |
| Take the card off screen | **Esc** or *Clear* |
| Points | **Q**/**W** = left player +1 Conquer/Hold, **A** = −1. **P**/**O** = right player +1 Conquer/Hold, **L** = −1. Or the ⚔/🛡/− buttons |
| Timer | **T** start/pause, ±1m buttons, *Reset* to the round length |
| Battlefield in play | Click it under the player's name (click again to unset) |
| Next game of the match | *New game*: points and battlefields reset, decks stay |
| Next feature match | *New match* (click twice): clears both players |

Keys only work when you're not typing in a box.

### Decklists (optional)

Paste the list into the player's *Decklist* box and press *Load decklist*. It reads the Piltover Archive / Riot event-locator format:

```
Legend:
1 Teemo, Swift Scout
Champion:
1 Teemo, Scout
MainDeck:
3 Bewitching Spirit
...
Battlefields:
1 Star Spring
...
Runes:
6 Chaos Rune
Sideboard:
...
```

It also accepts lists without headings, "3x" counts, and either "Name, Title" or "Name - Title". Lines it can't match are listed in yellow. You can still show any card with the search box.

## Pairings: feature matches from your bracket

Click **🏆 Pairings** and paste the bracket's **📱 Player link** from Pairings. Riftcast lists the current round's tables: names, legends, records coming into the round, and results as players report them (checked every 15 seconds). **📺 Feature** on a table starts a new match on stream with both names, records and legends (when the deck name clearly matches one legend), the bracket name, the store, the table and the round (Quarterfinals, Semifinals or Final in the top cut). It only reads the bracket, through the same public view players get, and never changes anything in Pairings.

## Players' phones: keep your own points

Players keep their points in **Riftbound Points** (https://beeftcg-eng.github.io/points/), a free phone app that also works on its own as a two-player counter, with or without the stream. Linked to the stream, a player's taps show on the overlay straight away, from any Wi-Fi or mobile data.

1. Click **📱 Phones** in the control panel. It shows a 6-character code and QR code for the **table** and for each player.
2. **One phone:** scan the **Table** code with a phone placed in the middle of the table. That phone keeps both players' points (the opponent's side is flipped to face them), and both show on the stream.
3. **Two phones:** each player scans **their own** code instead. Or they open the app, tap **📡 Link to stream** and type the code.
4. The 📱 button shows what is linked ("📱 Table phone", or "📱 Phones 2/2" for two players' phones).

- Each side has **⚔ Conquer** and **🛡 Hold** buttons (and −1 for corrections). Conquering for the final point asks whether every battlefield was scored this turn, per Riftbound's final-point rule. Riftcast's point log records which it was ("player app: conquer").
- 📜 **Log** shows the score history with conquer/hold totals and undo. Both players get a warning when either is one point from winning.
- A player's code only changes that player's points; while linked, the opponent's score comes from the stream. The table code changes both, and Reset on the table phone zeroes both on stream. Riftcast's point log shows "table phone: conquer" and so on.
- **New match** issues new codes, and the last match's apps go back to standalone counting. *Swap sides* keeps each app (and each side of the table phone) on its player.
- You can still change points from the control panel at any time; the phones follow.
- Linked phones show the round clock (⏱ 43:12) under each score. It turns amber in the last 5 minutes and red at time.
- The link goes through the Pairings Supabase project's Realtime channels (no database tables). The stream PC needs internet.

**Updating the app:** edit `points/`, preview it at http://localhost:7420/points/, then run `scripts/publish-points.sh` and push the site repo.

## Rift Atlas: digital games

Riftcast can follow games played on [Rift Atlas](https://play.riftatlas.com), whether you're playing or spectating. When a card is played, it goes on screen for the player who played it, at the exact printing used. Player names, legends and points follow the game too. No camera or typing needed.

**Set up once:** in the control panel open ⚙ Settings and drag the **Riftcast ↔ Rift Atlas** button to your Chrome bookmarks bar.

**Each game:** in the Rift Atlas game tab, click that bookmark. A small **"Riftcast: linked ●"** badge appears in the bottom-left of the game, and the control panel shows **🎮 Rift Atlas: Player vs Player**. The first time, Chrome asks whether play.riftatlas.com may access apps on this device: click **Allow** (that's how it reaches Riftcast). Click the badge to stop. After a page reload, click the bookmark again.

- Plays already in the log when you link are not replayed. Only new ones are shown.
- Face-down (Hidden) cards aren't shown until they're revealed. The connector only reads the board and the match log, never a player's hand.
- Players are matched by name, so it doesn't matter which seat you view the game from. A new pair of names on Rift Atlas sets them in Riftcast, left = the seat you're viewing.
- For the board itself on stream, Rift Atlas has its own caster views (`play.riftatlas.com/game/caster?...&output=match`, `battlefields`, `player-1`, …) that you can add as OBS Browser Sources.

## Table camera: cards shown automatically

Riftcast can watch the table camera and put a played card on screen by itself, with no decklists and no typing. It takes pictures of your table-camera source **through OBS**, so OBS keeps using the camera as normal.

**How it decides:** once a new card has stayed still on the table for 2 seconds (adjustable), it matches the card's picture against every Riftbound card and shows it under the player whose half it's on. Moving hands are ignored until they leave. Exhausting (turning) or moving a card that was already shown doesn't show it again, but a second copy does. Cards already on the table when the camera starts, or when you press *New game*, are left alone. It only shows a card when it's confident. Otherwise the card appears in the control panel under **"Camera isn't sure"** for one-click showing. When it does show a card, the control panel offers its runner-up guesses as **"wrong?"** buttons.

### Setting it up (once per venue)

1. In OBS: **Tools → WebSocket Server Settings** → tick **Enable WebSocket server**. *Show Connect Info* gives the password.
2. Click **📷** in the control panel to open the Camera page, enter the password, then **Connect & list sources** and pick the table camera.
3. Tick **Camera on**. The first time, it spends about a minute learning what all 1,451 cards look like (it downloads small images once).
4. Draw on the picture:
   - **Table area:** drag around both playmats.
   - **One card:** drag tightly around one upright card. This tells it how big cards are. It matters a lot.
   - **Ignore zones:** decks, trash piles, rune pools, the score track. Anything that changes often but shouldn't be shown.
   - **Split line:** click where the halves meet. Use *Swap which half is whose* if the names are on the wrong side.
5. Put a card down and watch the *What it saw* list. Each line shows **score / lead**: how alike the card is, and how far ahead of the next-best card. The default bar is score 0.62 and lead 0.08.

**For good results:** mount the camera straight above the table, use even, soft light (glare on a sleeve is the main thing that stops it recognising a card), and use matte sleeves if you can. Cards should be at least about 80 px wide in the camera picture: a 1080p camera covering one table is fine, a 4K one is better. Untick *Put recognised cards on screen by themselves* to have it only suggest cards.

**No camera yet?** On the Camera page, use *1. Empty table…* then *2. With a card played…* with two phone photos taken from where the camera will go. It reports what it would have done.

**Testing without a table:** `npm run eval` draws real cards onto a fake playmat with camera flaws (tilt, upside-down, sleeves, glare, colour cast, noise) and reports how many were recognised. On the synthetic tests so far: 80–89% shown automatically, the rest offered as suggestions, **no wrong card shown**, and no face-down card or hand shown as a card.

## Stream Deck / OpenDeck buttons

Use a "Website" or "HTTP request" action with these URLs. Players are `0` = left, `1` = right.

```
http://localhost:7420/api/do?type=points&player=0&delta=1      left player +1 point
http://localhost:7420/api/do?type=points&player=1&delta=1      right player +1 point
http://localhost:7420/api/do?type=points&player=0&delta=-1     left player −1
http://localhost:7420/api/do?type=clear                        clear the card
http://localhost:7420/api/do?type=timerToggle                  start/pause timer
http://localhost:7420/api/do?type=newGame                      next game
http://localhost:7420/api/do?type=swapSides                    swap players
http://localhost:7420/api/showByName?name=Bewitching%20Spirit&player=0
http://localhost:7420/api/camera/auto?on=toggle                camera: auto-show on/off
http://localhost:7420/api/camera/enabled?on=toggle             camera on/off
http://localhost:7420/api/camera/reset                         camera: forget what's on the table
```

## Settings (⚙)

These are the points to win, best-of, how long a card pops big (0 = straight to the side panel), whether the card hides after some seconds (0 = keep it up), camera frames, the "played by" tag, the accent colour, and *Update card list* (use it after a new set releases).

## Updates

Riftcast checks for a new version when it starts and every few hours. When there is one, a green **⬆ Update** button appears at the top of the control panel. Click it, then **Install**: Riftcast downloads the new version, checks it isn't damaged, installs it over the old one (your saved match, codes, card list and camera setup in `data/` are kept) and restarts by itself. Open pages, including the OBS sources, reload on their own. Started without `start.bat` / `start.sh`, it asks you to start it again instead. ⚙ Settings → Updates has *Check for updates* and the release notes.

Publishing an update (for the organiser): bump `version` in `package.json`, commit, run `scripts/publish-release.sh "What's new"`, then commit and push the site repo it prints. The newest zip is also at https://beeftcg-eng.github.io/riftcast/riftcast.zip for first installs.

## Development

`npm test` runs the decklist and scoring tests. State is kept in `data/state.json`, so a restart picks up where it left off.
